(function (lib, img, cjs, ss) {

var p; // shortcut to reference prototypes

// library properties:
lib.properties = {
	width: 550,
	height: 400,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: []
};



lib.ssMetadata = [];


// symbols:



(lib.Symbol17 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgZCjQgMgMABgPQgBgQAMgLQAMgLANAAQAPAAAMALQALALgBAQQABAQgLALQgMALgPAAQgNAAgMgLgAgEBQIgLgpIgOg4IgFgXIgHgkQgDgRABgOQAAgeALgSQALgSAVAAQANAAAKAIQAKAIAGAQQAFAPABATQAAAVgFAZQgDAZgGATIgNAzIgNAug");
	this.shape.setTransform(484.9,32);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AiDCsIAAgHQAbAAAIgMQAIgNAAgTIAAjwQAAgTgHgOQgIgNgaABIgCAAIAAgHID3AAIADBNIgHAAQgFgTgFgNQgGgNgLgGQgLgHgRAAIhEAAIAACRIA1AAQAZAAALgLQAMgLACgVIAHAAIAABjIgHAAQgDgXgOgIQgOgIgTABIg1AAIAABjQAAArAqAAIAVAAQAWAAANgGQANgFAKgOQAIgOAIgZIAGAAIgFBTg");
	this.shape_1.setTransform(450.1,31.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("ACUCuIj7kIIAADAQAAAZALARQAKARAcACIAAAHIh7AAIAAgHQA0gEgBgvIAAjiIgDgEIgHgGIgJgIQgggfgXgDIAAgHIB9AAIDQDcIAAicQAAgfgMgLQgNgMgagDIAAgHIB3AAIAAAHQgUABgJAJQgKAJgDALQgCAMAAAPIAAEbg");
	this.shape_2.setTransform(400.4,32);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AhPCgQgigQgXgaQgVgagLggQgKgfAAgdQAAgjALggQANggAXgYQAXgZAigNQAhgOApAAQAqAAAhAOQAiAOAXAYQAXAYAMAhQANAfAAAjQAAAjgMAgQgMAggWAYQgXAYgiAOQgiAPgrAAQgsAAgjgQgAhAh/QgWAdgFAgQgGAhABAdQgBAhAGAiQAFAiAWAeQAWAdArAAQA9AAASgyQARgyABg0QgBgmgGgkQgIgjgVgZQgWgagnAAQgrAAgWAdg");
	this.shape_3.setTransform(344.9,31.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("Ai+CsIAAgHQAcAAAIgMQAHgMAAgUIAAjwQAAgTgHgNQgHgNgaAAIgDAAIAAgHIC9AAQAsAAAlAOQAlAOAYAZQAZAZAMAgQANAhAAAhQAAAjgMAdQgLAegYAYQgXAXgkANQgjANgsAAgAhGiUIAAD7QAAASAEALQAEAKALAGQAMAFAWAAQATAAAQgDQAQgDAOgHQAWgNANgVQAOgWAGgZQAHgZAAgcQAAgagIgbQgHgcgRgZQgRgXgdgOQgdgPgoAAQgPAAgSAEg");
	this.shape_4.setTransform(289.2,31.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AiICsIAAgHQAbAAAIgMQAIgMgBgUIAAjwQAAgXgJgLQgKgLgXAAIAAgHIChAAIAAAHQgZAAgIAMQgIALAAAWIAADkQgBAWAJALQAIALAVAAIAZAAQAYAAAVgNQAWgMARgtIAHAAIgMBZg");
	this.shape_5.setTransform(208.7,31.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AiICsIAAgHQAbAAAIgMQAIgMgBgUIAAjwQABgXgKgLQgKgLgXAAIAAgHIChAAIAAAHQgZAAgIAMQgIALgBAWIAADkQAAAWAJALQAIALAVAAIAYAAQAZAAAVgNQAWgMARgtIAHAAIgMBZg");
	this.shape_6.setTransform(164.7,31.8);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AiDCsIAAgHQAbAAAIgMQAIgNAAgTIAAjwQAAgTgHgOQgIgNgaABIgCAAIAAgHID3AAIADBNIgHAAQgFgTgGgNQgFgNgLgGQgLgHgRAAIhEAAIAACRIA1AAQAZAAALgLQAMgLACgVIAHAAIAABjIgHAAQgEgXgOgIQgNgIgTABIg1AAIAABjQAAArAqAAIAWAAQAVAAANgGQANgFAKgOQAJgOAHgZIAGAAIgFBTg");
	this.shape_7.setTransform(121.2,31.8);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("ABgCuIhfkcIgBAAIhiEcIgIAAIhkkrQgGgSgJgJQgIgJgJgCQgJgDgJAAIAAgHICfAAIAAAHQgNABgKAGQgIAHgBAMQAAAIAFAMIAyCYIABAAIA+ivQgFgJgFgFQgFgFgHgCIgUgCIAAgHICaAAIAAAHQgOAAgIADQgJAEABANIABAJIADAMIACAHIAzCWIAAAAIAwiNQAGgRAAgKQAAgTgKgFQgLgGgPAAIAAgHIBuAAIAAAHQgTACgNAPQgOAOgLAfIhgEWg");
	this.shape_8.setTransform(66.3,32);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#000000").ss(2,1,1).p("EgpJgD5MBSTAAAIAAHzMhSTAAAg");
	this.shape_9.setTransform(263.5,30.8);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("EgpJAD5IAAnxMBSTAAAIAAHxg");
	this.shape_10.setTransform(263.5,30.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,0,529,61.8);


(lib.Symbol16 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("AlpvkIigAAIAAiRIQTAAIAACRIkJAAIpqAAIAAD6IC5AAIAAFYIlZAAIAAlYICgAAAkKpKQAAAngcAcQgbAcgoAAQgnAAgcgcQgcgcAAgnQAAgoAcgcQAcgbAnAAQAoAAAbAbQAcAcAAAogAIKvkMAAAAhaIkJAAMAAAgha");
	this.shape.setTransform(52.2,114.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FF0000").s().p("AhCBCQgbgbgBgnQABgmAbgcQAcgbAmgBQAnABAbAbQAcAcAAAmQAAAngcAbQgbAcgnAAQgmAAgcgcg");
	this.shape_1.setTransform(16,55.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AEBR2MAAAghaIEJAAIkJAAIpqAAIigAAIAAiRIQTAAIAACRMAAAAhagAoJmRIAAlZICgAAIC5AAIAAFZgAmsqNQgcAcAAAnQAAAoAcAbQAcAcAnAAQAoAAAbgcQAcgbAAgoQAAgngcgcQgbgcgoAAQgnAAgcAcg");
	this.shape_2.setTransform(52.2,114.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,106.5,230.5);


(lib.Symbol15 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("ACHwKIAABkIAABaIAABfIAABpIAABmIAABiACHxtIAABjAiFw8IAAgxIBjAAICpAAAiFumIAAhkIAAgyIBjgxAiFqOIAAhpIAAhfIEMhQAiFumIEMhkAiFwKIEMhjAiFqOIEMhfAiFr3IEMhVAiFtWIAAhQAiFnEIAAhcIEMhkAiFiuIAAhfIAAhLIAAhsIEMhaACHlvIAABdIAABpAiFlYIEMhkIAABNAiFkNIEMhiAiFiuIEMhkAiFogIAAhuAiFAkIEMhsIAABsIBIAAIAAHbIhIAAIAABLIAABLIAABaIAABTIAABLIAABIIAABBIAAAsIAAAsIhVAAIi3AAIEMhYAiFAkIEMAAAiFAkIAAhiIEMhrIAABhAiFH/IhJAAIAAnbIBJAAAiFJLIAAhMAiFLqIAAhSIEMhOAiFNEIAAhaIEMhVACHH/IkMAAAiFJLIEMhMAiFNEIEMhVAiFKYIAAhNAiFg+IAAhwAiFPaIAAg+IEMhaAiFQlIAAhLIEMhNAiFRuIAAhJIEMhQAAyRuIBVgsAiFOcIAAhY");
	this.shape.setTransform(20.8,113.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAxRuIi2AAIEMhYIAAAsIhWAsIBWgsIAAAsgAiFRuIAAhJIEMhQIAABBIkMBYgAiFPaIEMhNIAABIIkMBQgACHQWgAiFOcIEMhaIAABLIkMBNgAiFNEIAAhaIEMhVIAABaIkMBVIEMhVIAABTIkMBagAiFKYIEMhOIAABLIkMBVgAiFJLIAAhMIhJAAIAAnbIBJAAIEMAAIkMAAIEMhsIAABsIBIAAIAAHbIhIAAIkMAAIEMAAIkMBMIEMhMIAABLIkMBOgACHKVgAiFg+IEMhrIAABhIkMBsgAiFiuIAAhfIAAhLIAAhsIEMhaIAABiIkMBkIEMhkIAABNIkMBiIEMhiIAABdIkMBkIEMhkIAABpIkMBrgAiFogIEMhkIAABmIkMBagAiFqOIEMhfIAABpIkMBkgAiFr3IAAhfIEMhQIAABaIkMBVIEMhVIAABfIkMBfgACHrtgACHtMgAiFumIEMhkIAABkIkMBQgAiFwKIAAgyIBkgxICoAAIkMBjIEMhjIAABjIkMBkgAiFxtIBkAAIhkAxgAghxtg");
	this.shape_1.setTransform(20.8,113.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,43.5,229);


(lib.Symbol14 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("EgzaABGMB1vAAAIAAHWMh1vAAAIAAnUEhCUgIbIHMAAIAAQ3InMAAg");
	this.shape.setTransform(424.5,54);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("EgzZAIcIAAnUIAAgCMB1tAAAIAAHWgEhCUAIcIAAw3IHMAAIAAQ3g");
	this.shape_1.setTransform(424.5,54);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,851,110);


(lib.Symbol13 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("Aj2kmIHtAAIkpJNg");
	this.shape.setTransform(24.7,29.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Aj2kmIHtAAIkpJNg");
	this.shape_1.setTransform(24.7,29.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,51.4,61);


(lib.Symbol12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("AnzAtIAAkNIPnAAIAAENIhYAAQAkABAZAZQAbAaAAAmQAAAlgbAaQgaAbglAAQgmAAgbgbQgZgaAAglQAAgmAZgaQAagZAlgBIsQAAQAkABAZAZQAaAaAAAmQAAAlgaAaQgaAbgmAAQglAAgbgbQgagaAAglQAAgmAagaQAagZAkgB");
	this.shape.setTransform(50,22.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AFZDGQgagaAAglQAAgmAagaQAagaAlAAIsQAAQAkAAAZAaQAaAaAAAmQAAAlgaAaQgaAbgmAAQglAAgbgbQgagaAAglQAAgmAagaQAagaAkAAIh2AAIAAkNIPmAAIAAENIhXAAQAkAAAZAaQAbAagBAmQABAlgbAaQgaAbgmAAQglAAgbgbg");
	this.shape_1.setTransform(50,22.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,102,47);


(lib.Symbol11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("AAANrIAA7V");
	this.shape.setTransform(0,87.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,2,177);


(lib.Symbol10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("Ak8CPIlyBtAKvj7IuOGn");
	this.shape.setTransform(68.7,64);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#FFFFFF").ss(0.7,1,1).p("AApADIhRAAIAAgFIBIAA");
	this.shape_1.setTransform(115,38.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#FFFFFF").ss(1,1,1).p("ABBAVIAAgaIESAAIAAAKAlRgUIGSAAIAAAPAFTAVIAAgQIAQAAAFjAMIAAAJIgQAAIkSAAImjAA");
	this.shape_2.setTransform(75.3,37.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AFvDHQgFgDgDgGQgMAAgHgDIhTAAIAAgHIBKAAQgFgGAAgIQgBgPANgIQgSABgYgEQgOgDgbgIIg0gPQgOgEgGgGQgIgHABgMQABgLAIgGQANgKAdAKIAkALQAgAKAUACQAVADAogBQA7ADAxAkQALAIACAGQAEAHgCAIQgBAIgGAFQgHAHgRACIgBABQgFADgIADIgdAKQgHADgIAAIgWABQgOAAgHgFgAnUDEIgCAAQgNgFgCgPQAAgMgBgGQAAgEgEgHIgDgLQgBgFACgHIAFgMQACgIgBgSIgFg0QgEgfAEgcQAEgUgBgHIgCgNIgEgNQgCgNAAgWQABgagBgJIgCgYQABgPAGgIQAIgIAMAAQAMABAHAJQAFAIABAPIABAiIAAAkIAGAcQADARgDASIgDAUQgBAMACAGIAEANQAFAQgCAhIgDBMIACAOIGUAAIAAAPIEQAAIAAAMIAAAQIkQAAIAAgcIAAAcImlAAQgEABgEAAIgIgBgADxDEIAAgQIAQAAIAAAHIAAAJgAEBC0g");
	this.shape_3.setTransform(85.1,20.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,0,139.4,90.3);


(lib.Symbol8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(3,1,1).p("A8xIZMA4NgUcIBWDrMg4NAUcg");
	this.shape.setTransform(184.2,77.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("A8xIZMA4NgUcIBVDrMg4MAUcg");
	this.shape_1.setTransform(184.2,77.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1.5,-1.5,371.4,157.5);


(lib.Symbol7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(3,1,1).p("AspLeIZTAAIAAKUI5TAAgAAi1xMAAAAg8");
	this.shape.setTransform(81,139.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AspFKIAAqSIZTAAIAAKSg");
	this.shape_1.setTransform(81,245.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1.5,-1.5,165,281.9);


(lib.Symbol6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("ALLAAQAAEnjSDSQjSDSknAAQknAAjRjSQjSjSAAknQAAknDSjRQDRjSEnAAQEnAADSDSQDSDRAAEng");
	this.shape.setTransform(71.5,71.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("An4H5QjSjRAAkoQAAkmDSjSQDSjSEmAAQEoAADRDSQDSDSAAEmQAAEojSDRQjRDSkoAAQkmAAjSjSg");
	this.shape_1.setTransform(71.5,71.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,145,145);


(lib.Symbol5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AovxGIRfAAMAAAAiNIxfAAg");
	this.shape.setTransform(56,109.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AovRGMAAAgiMIReAAMAAAAiMg");
	this.shape_1.setTransform(56,109.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,114,221);


(lib.Symbol4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AH0E/IvnAAIAAmDIPnj6");
	this.shape.setTransform(50,166.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(2,1,1).p("AABvgQACE9gCGHQgBFtgBEQIAAKA");
	this.shape_1.setTransform(100.2,99.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AnzE/IAAmDIPmj6IAAJ9g");
	this.shape_2.setTransform(50,166.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,102.5,200.6);


(lib.Symbol3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AB0s/IAHAAIAAAMIDSFmIjSABIkgACIjtACIFsqAICaEJIAHAMAB7JfIEYAAIAAHqIsUAAIAAnqIDcAAgAB7nMIAAQrAilJfIAAwp");
	this.shape.setTransform(40.3,109.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgIAYIgCgBIgIgIIgDgGQAAgDAAgGIgCAAIAFgLQABgDADgBIAEgEQAGgEACgBIAFABQAOADAFALIACAGIAAADIAAACIgEAMIgEAEIgEAEQgEACgFAAIgIABg");
	this.shape_1.setTransform(37.4,41.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AmBRJIAAnqIDcAAIEgAAIEYAAIAAHqgAilJfIAAwpIEggCIAAQrgAilJfgAgmxIICaEJIAHAMIgHgMIAHAAIAAAMIDSFmIjSABIkgACIjtADgAgnq7IgEAEQgDABgBAEIgGAMIADAAQgBAGABADIADAGIAIAIIACACIADAAIAJAAQAGAAADgDIAFgEIADgDIAFgNIAAgCIAAgFIgCgFQgFgMgOgDIgHgBQgDABgFAEgAB7nMg");
	this.shape_2.setTransform(40.3,109.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,82.7,221.5);


(lib.Symbol2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AEVAAQAABzhRBRQhRBRhzAAQhyAAhRhRQhRhRAAhzQAAhyBRhRQBRhRByAAQBzAABRBRQBRBRAAByg");
	this.shape.setTransform(27.8,27.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AjDDDQhRhQAAhzQAAhxBRhSQBShRBxAAQBzAABQBRQBSBSAABxQAABzhSBQQhQBShzAAQhxAAhShSg");
	this.shape_1.setTransform(27.8,27.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,57.5,57.5);


(lib.Symbol1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("Ah6peIkYAAIAAnqIMUAAIAAHqIjcAAgAh6M0IjSlmIDSgCIEggBIDtgDIlsKBIiakJgAhzNAIgHAAIAAgMAh6HMIAAwqACmpeIAAQp");
	this.shape.setTransform(40.3,109.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgCAYQgOgDgFgLIgCgGIAAgEIAAgBIAEgMIAEgEIAEgEQAEgCAFAAIAIgBIADABIACABIAIAIIADAGQABADgBAFIACAAIgFAMQgCADgCABIgEAEQgGAEgCABg");
	this.shape_1.setTransform(43.3,177.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AhzNAIgHgMIjSlmIDSgBIAAwrIEgAAIkgAAIkYAAIAAnqIMUAAIAAHqIjcAAIAAQoIkgADIEggDIDtgCIlsKBgAAaKOQgGAAgDACIgFAFIgDADIgFANIAAACIAAAEIACAGQAFAMAOADIAHABQADgBAFgEIAEgEQADgBABgEIAGgLIgDAAQABgIgBgCIgDgGIgIgIIgCgCIgDAAIgJAAgAh6NAIAAgMIAHAMg");
	this.shape_2.setTransform(40.3,109.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,82.7,221.5);


(lib.Symbol9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Symbol4();
	this.instance.setTransform(54,99.3,1,1,0,0,0,50.5,99.3);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1,1,1).p("AgVgQIAABcIAABOIArAAIAAkzIgrAAIAAAIIAAAxIAABH");
	this.shape.setTransform(9.4,184.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgTDbQgMgBgGgJQgEgHgBgQQgFgJAAgTQABgbAFgaIABgHIAChJIgFgMQgDgKAAgUIAAhGIAAgZIgGgWQgGgVACgJQADgPALgIQABgNAEgGQAFgJAMgCQAMgCAIAHQAGAHACANQAFAEADAHQABAFAAAIIAAANIAAAMQAAAHgBAEIgEAJIAAAIIAAgIIAtAAIAAEzIgtAAIAAhOIAAheIAABeIgCAGIgDALIABA0QAAAdgJAJQgGAGgIAAIgEAAgAAMADIAAhFgAAJhqIgBAEIABAEQACAMABAUIAAgxQAAAEgDAFg");
	this.shape_1.setTransform(5.8,181.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-1,105,204.5);


// stage content:
(lib.Simplemachines2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Sign
	this.instance = new lib.Symbol17();
	this.instance.setTransform(275.5,-31.8,1,1,0,0,0,263.4,30.9);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(152).to({_off:false},0).wait(1).to({regX:263.5,regY:30.8,x:275.6,y:-24.8},0).wait(1).to({y:-17.7},0).wait(1).to({y:-10.6},0).wait(1).to({y:-3.5},0).wait(1).to({y:3.6},0).wait(1).to({y:10.7},0).wait(1).to({y:17.8},0).wait(1).to({y:24.8},0).wait(1));

	// Kart
	this.instance_1 = new lib.Symbol12();
	this.instance_1.setTransform(105.5,445.5,1,1,0,0,0,50,22.5);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(100).to({_off:false},0).wait(1).to({x:103.1,y:429},0).wait(1).to({x:100.7,y:412.4},0).wait(1).to({x:98.3,y:395.9},0).wait(1).to({x:95.9,y:379.4},0).wait(1).to({x:93.5,y:362.9},0).wait(2).to({x:111.2},0).wait(1).to({x:128.9},0).wait(1).to({x:146.7},0).wait(1).to({x:164.4},0).wait(1).to({x:182.1},0).wait(1).to({x:199.8},0).wait(1).to({x:217.5},0).wait(1).to({x:235.3},0).wait(1).to({x:253},0).wait(1).to({x:270.7},0).wait(1).to({x:275.7},0).wait(1).to({x:280.7},0).wait(1).to({x:285.6},0).wait(1).to({x:290.6},0).wait(1).to({x:295.6},0).wait(1).to({x:300.6},0).wait(1).to({x:305.6},0).wait(1).to({x:310.5},0).wait(1).to({x:315.5},0).wait(1).to({x:320.5},0).wait(1).to({x:325.5},0).wait(1).to({x:330.5},0).wait(1).to({x:335.5},0).wait(1).to({x:355.8},0).wait(1).to({x:376.2},0).wait(1).to({x:396.5},0).wait(1).to({x:416.9},0).wait(1).to({x:437.2},0).wait(1).to({x:457.6},0).wait(1).to({x:477.9},0).wait(1).to({x:498.3},0).wait(1).to({x:518.6},0).wait(1).to({x:539},0).wait(1).to({x:559.3},0).wait(1).to({x:579.7},0).wait(1).to({x:600},0).to({_off:true},1).wait(18));

	// Floor 2
	this.instance_2 = new lib.Symbol14();
	this.instance_2.setTransform(253.3,461,1,1,0,0,0,284.2,54);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(100).to({_off:false},0).wait(1).to({regX:424.5,x:391,y:444.9},0).wait(1).to({x:388.4,y:428.7},0).wait(1).to({x:385.8,y:412.6},0).wait(1).to({x:383.2,y:396.5},0).wait(1).to({x:380.6,y:380.4},0).wait(1).to({regX:284.2,x:240.3},0).wait(1).to({regX:424.5,x:380.7},0).wait(1).to({x:380.8},0).wait(1).to({x:380.9},0).wait(1).to({x:381},0).wait(1).to({x:381.2},0).wait(1).to({x:381.3},0).wait(1).to({x:381.4},0).wait(1).to({x:381.5},0).wait(1).to({x:381.6},0).wait(1).to({x:381.7},0).wait(1).to({x:362},0).wait(1).to({x:342.3},0).wait(1).to({x:322.6},0).wait(1).to({x:302.9},0).wait(1).to({x:283.2},0).wait(1).to({x:263.5},0).wait(1).to({x:243.8},0).wait(1).to({x:224.1},0).wait(1).to({x:204.4},0).wait(1).to({x:184.7},0).wait(1).to({x:165},0).wait(1).to({x:145.3},0).wait(1).to({x:125.5},0).wait(24).to({regX:284.2,x:-14.8},0).wait(1).to({regX:424.5,x:125.5},0).wait(7));

	// Screw
	this.instance_3 = new lib.Symbol15();
	this.instance_3.setTransform(570.8,320.9,1,1,0,0,0,20.8,113.5);
	this.instance_3._off = true;

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("ADNDoImZAAIAAnPIGZAA");
	this.shape.setTransform(487.5,348);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AjMDoIAAnPIGZAAIAAHPg");
	this.shape_1.setTransform(487.5,348);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(2,1,1).p("Ak2w8IAAgxIBjAAICrAAIAABjIAABkIAABaIAABfIAABpIAABmIAABiIAABNIAABdIAABpIAABhIAABsIC6AAAk2tWIAAhQIAAhkIAAgyIBjgxAk2qOIAAhpIAAhfIEOhQAk2iuIAAhfIAAhLIAAhsIAAhcIAAhuIEOhfAk2IIIhSAAIAAnkIBSAAIAAhiIAAhwIEOhkAk2KYIAAhNIAAhDAk2NEIAAhaIAAhSIEOhOIAABLIAABaIAABTIAABLIAABIIAABBIAAAsACSIIIi6AAIggAAIjuAAAgoIIIAABCACSIIIAAnkID3AAIAAHkgAk2NEIEOhVAk2AkIEOAAAk2JLIDuhDAk2r3IEOhVAk2wKIEOhjAk2umIEOhkAk2kNIEOhiAk2nEIEOhaAk2lYIEOhkAk2ogIEOhkAk2AkIEOhsAk2LqIEOhVAk2g+IEOhrAh+RuIBWgsIAAAsIhWAAIi4AAIAAhJIEOhQAk2PaIAAg+IEOhaAk2QlIAAhLIEOhNAk2RuIEOhYAk2OcIAAhY");
	this.shape_2.setTransform(505.3,310.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("Ah+RuIBWgsIAAAsgAk2RuIEOhYIAAAsIhWAsgAk2RuIAAhJIEOhQIAABBIkOBYgAk2PaIAAg+IEOhaIAABLIkOBNIEOhNIAABIIkOBQgAk2NEIAAhaIAAhSIAAhNIAAhDIhSAAIAAnkIBSAAIAAhiIAAhwIAAhfIAAhLIAAhsIAAhcIAAhuIAAhpIAAhfIAAhQIAAhkIAAgyIBjgxICrAAIkOBjIEOhjIAABjIkOBkIEOhkIAABkIkOBQIEOhQIAABaIkOBVIEOhVIAABfIkOBfIEOhfIAABpIkOBkIEOhkIAABmIkOBaIEOhaIAABiIkOBkIEOhkIAABNIkOBiIEOhiIAABdIkOBkIEOhkIAABpIkOBrIEOhrIAABhIkOBsIEOAAIkOAAIEOhsIAABsIC6AAID3AAIAAHkIj3AAIAAnkIAAHkIi6AAIggAAIAgAAIAABCIkOBOIEOhOIAABLIkOBVIEOhVIAABaIkOBVIEOhVIAABTIkOBagAk2JLIDuhDgAhIIIIjuAAgAgoLvgAgoJKgAk2xtIBjAAIhjAxgAjTxtg");
	this.shape_3.setTransform(505.3,310.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(2,1,1).p("AiyxtIAABjIAABkIAABaIAABfIAABpIAABmIAABiIAABNIAABdIAABpIAABhIAABQIAAAcILAAAIAAHiIrAAAIAABEIAABLIAABaIAABTIAABLIAABIIAABBIAAAsAnAw8IBkgxICqAAAnAwKIAAgyIAAgxIBkAAAnAqOIAAhpIAAhfIAAhQIAAhkIEOhjAnAogIAAhuIEOhfAnAiuIAAhfIAAhLIAAhsIAAhcIEOhkAnAg+IAAhwIEOhkAnAIGIhNAAIAAniIBNAAIAAhiIEOhrAnALqIAAhSIAAhNIAAhFAnANEIAAhaIEOhVAnAOcIAAhYIEOhVAjyAkIBAAAAjyAkIBAgcAiyIGIgXAAIj3AAAnAOcIEOhaAnAKYIEOhOAnAAkIEOhsAnAlYIEOhkAnAnEIEOhaAnAkNIEOhiAnAtWIEOhQAnAumIEOhkAnAr3IEOhVAnAAkIDOAAAnAJLID3hFAkHRuIBVgsIAAAsIhVAAIi5AAIEOhYAnARuIAAhJIAAhLIEOhNAnAQlIEOhQAnAPaIAAg+");
	this.shape_4.setTransform(519.1,300.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AkHRuIi5AAIEOhYIAAAsIhVAsIBVgsIAAAsgAnAQlIAAhLIEOhNIAABIIkOBQIEOhQIAABBIkOBYgAnAOcIAAhYIAAhaIAAhSIAAhNIAAhFIhNAAIAAniIBNAAIAAhiIAAhwIAAhfIAAhLIAAhsIAAhcIAAhuIAAhpIAAhfIAAhQIAAhkIAAgyIBkgxICqAAIkOBjIEOhjIAABjIkOBkIEOhkIAABkIkOBQIEOhQIAABaIkOBVIEOhVIAABfIkOBfIEOhfIAABpIkOBkIEOhkIAABmIkOBaIEOhaIAABiIkOBkIEOhkIAABNIkOBiIEOhiIAABdIkOBkIEOhkIAABpIkOBrIEOhrIAABhIkOBsIDOAAIBAAAIhAAAIBAgcIAAAcILAAAIAAHiIrAAAIgXAAIAXAAIAABEIkOBOIEOhOIAABLIkOBVIEOhVIAABaIkOBVIEOhVIAABTIkOBaIEOhaIAABLIkOBNgAnAJLID3hFIj3AAID3AAgAiyLvgAiyJKgAiyIGgAnAAkIEOhsIAABQIhAAcgAnAAkgAnAxtIBkAAIhkAxgAiyxtg");
	this.shape_5.setTransform(519.1,300.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").ss(2,1,1).p("AgowKIAABkIAABaIAABfIAABpIAABmIAABiIAABNIAABdIAABpIAABhIAABQIAAAcIGxAAIAAHkImxAAIggAAIhJAAIilAAIhSAAIAAnkIBSAAIAAhiIAAhwIAAhfIAAhLIAAhsIAAhcIAAhuIAAhpIAAhfIAAhQIAAhkIAAgyIAAgxIBkAAICqAAgAk2w8IBkgxAk2LqIAAhSIAAhNIAAhDAk2PaIAAg+IAAhYIAAhaIEOhVIAABaIAABTIAABLIAABIIAABBIAAAsAhoAkIBAgcAhoAkIBAAAAiRAkIApAAAgoJKIAABLAgoIIIAABCAiRAkIAAHkAk2AkIEOhsAk2JLIDuhDAk2AkIClAAAk2r3IEOhVAk2qOIEOhfAk2wKIEOhjAk2umIEOhkAk2tWIEOhQAk2iuIEOhkAk2kNIEOhiAk2nEIEOhaAk2lYIEOhkAk2ogIEOhkAk2KYIEOhOAk2g+IEOhrAk2OcIEOhaAk2NEIEOhVAk2PaIEOhNAh9RuIBVgsIAAAsIhVAAIi5AAIAAhJIAAhLAk2QlIEOhQAk2RuIEOhY");
	this.shape_6.setTransform(505.3,290.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("Ah9RuIBVgsIAAAsgAk2RuIEOhYIAAAsIhVAsgAk2RuIAAhJIAAhLIEOhNIAABIIkOBQIEOhQIAABBIkOBYgAk2OcIEOhaIAABLIkOBNgAgoPVgAk2NEIEOhVIAABTIkOBagAk2LqIEOhVIAABaIkOBVgAk2KYIEOhOIAABLIkOBVgAk2JLIAAhDIhSAAIAAnkIBSAAIAAhiIAAhwIAAhfIAAhLIAAhsIAAhcIAAhuIAAhpIEOhVIAABfIkOBfIEOhfIAABpIkOBkIEOhkIAABmIkOBaIEOhaIAABiIkOBkIEOhkIAABNIkOBiIEOhiIAABdIkOBkIEOhkIAABpIkOBrIEOhrIAABhIkOBsIClAAIAAHkIBJAAIAgAAIAABCIkOBOgAk2JLIDuhDgAiRIIIilAAgAgoIIIggAAIhJAAIAAnkIilAAIEOhsIAABQIhAAcIBAAAIGxAAIAAHkgAhoAkIgpAAgAiRIIgAhoAkIBAgcIAAAcgAgohIgAk2tWIEOhQIAABaIkOBVgAk2umIEOhkIAABkIkOBQgAk2wKIAAgyIAAgxIBkAAIhkAxIBkgxICqAAIkOBjIEOhjIAABjIkOBkgAgoxtg");
	this.shape_7.setTransform(505.3,290.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#000000").ss(2,1,1).p("AB9wKIAABkIAABaIAABfIAABpIAABmIAABiIAABNIAABdIAABpIAABhIAABQIAAAcIBJAAIAAHbImGAAIAAgKIgFAAAB9xtIAABjAiPumIAAhkIAAgyIAAgxIBkAAICoAAAiPtWIAAhQIEMhkAiPw8IBkgxAiPnEIAAhcIAAhuIAAhpIAAhfIEMhQAiPlYIAAhsIEMhaAjAAkIAxAAIAAhiIAAhwIAAhfIAAhLIEMhkAjFAkIAFAAIAAHRAiPJLIAAhDAiPLqIAAhSIAAhNIDshDAiPPaIAAg+IAAhYIAAhaIEMhVIAABaIAABTIAABLIAABIIAABBIAAAsIAAAsIhVAAIBVgsAiPQlIAAhLIEMhNAiPRuIAAhJIEMhQAA9AkIBAgcAA9AkIBAAAAB9IIIAABCIAABLAiPAkIDMAAAiPr3IEMhVAiPqOIEMhfAiPwKIEMhjAiPiuIEMhkAiPkNIEMhiAiPogIEMhkAiPAkIEMhsAiPKYIEMhOAiPg+IEMhrAAoRuIi3AAIEMhYAiPOcIEMhaAiPNEIEMhV");
	this.shape_8.setTransform(488.6,280.9);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AAoRuIBVgsIAAAsgAiPRuIEMhYIAAAsIhVAsgAiPRuIAAhJIAAhLIAAg+IAAhYIAAhaIAAhSIAAhNIDshDIjsBDIAAhDIDsAAIAgAAIAABCIkMBOIEMhOIAABLIkMBVIEMhVIAABaIkMBVIEMhVIAABTIkMBaIEMhaIAABLIkMBNIEMhNIAABIIkMBQIEMhQIAABBIkMBYgAB9JKgAjAH/IAAgKIgFAAIAAnRIAFAAIAxAAIAAhiIAAhwIAAhfIAAhLIAAhsIAAhcIAAhuIAAhpIAAhfIAAhQIEMhkIAABkIkMBQIEMhQIAABaIkMBVIEMhVIAABfIkMBfIEMhfIAABpIkMBkIEMhkIAABmIkMBaIEMhaIAABiIkMBkIEMhkIAABNIkMBiIEMhiIAABdIkMBkIEMhkIAABpIkMBrIEMhrIAABhIkMBsIDMAAIjMAAIEMhsIAABQIhAAcIBAAAIBJAAIAAHbgAjAH1IAAnRgAA9AkIBAgcIAAAcgAA9AkgAiPwKIAAgyIAAgxIBkAAIhkAxIBkgxICoAAIkMBjIEMhjIAABjIkMBkgAB9xtg");
	this.shape_9.setTransform(488.6,280.9);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#000000").ss(2,1,1).p("AFAwKIAABkIAABaIAABfIAABpIAABmIAABiIAABNIAABdIAABpIAABhIAABQIAAAcIBJAAIAAHkIhJAAIggAAIjuAAIjDAAIj3AAIAAnkID3AAIDDAAIAAhiIAAhwIAAhfIAAhLIAAhsIAAhcIAAhuIAAhpIAAhfIAAhQIAAhkIAAgyIAAgxIBkAAICqAAgAAyw8IBkgxAAyJLIAAhDAAyLqIAAhSIAAhNIDuhDAAyPaIAAg+IAAhYIAAhaIEOhVAAyQlIAAhLIEOhNIAABIIAABBIAAAsAAyRuIAAhJIEOhQAiRAkIAAHkAEAAkIBAgcAEAAkIBAAAAFAIIIAABCIAABLIAABaIAABTIAABLADrRuIBVgsIAAAsIhVAAIi5AAIEOhYAAyAkIDOAAAAyr3IEOhVAAyqOIEOhfAAywKIEOhjAAyumIEOhkAAytWIEOhQAAyiuIEOhkAAykNIEOhiAAynEIEOhaAAylYIEOhkAAyogIEOhkAAyAkIEOhsAAyKYIEOhOAAyg+IEOhrAAyOcIEOhaAAyNEIEOhV");
	this.shape_10.setTransform(469.1,270.9);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("ADrRuIi5AAIEOhYIAAAsIhVAsIBVgsIAAAsgAAyRuIAAhJIAAhLIAAg+IAAhYIAAhaIAAhSIAAhNIAAhDIjDAAIAAnkIDDAAIAAhiIEOhrIAABhIkOBsIEOhsIAABQIhAAcIBAAAIBJAAIAAHkIhJAAIggAAIAgAAIAABCIkOBOIEOhOIAABLIkOBVIEOhVIAABaIkOBVIEOhVIAABTIkOBaIEOhaIAABLIkOBNIEOhNIAABIIkOBQIEOhQIAABBIkOBYgAAyJLIDuhDgAEgIIIjuAAgAEAAkIjOAAgAFALvgAFAJKgAmIIIIAAnkID3AAIAAHkgAEAAkIBAgcIAAAcgAEAAkgAAyiuIAAhfIAAhLIAAhsIAAhcIAAhuIEOhfIAABpIkOBkIEOhkIAABmIkOBaIEOhaIAABiIkOBkIEOhkIAABNIkOBiIEOhiIAABdIkOBkIEOhkIAABpIkOBrgAFAhIgAFAm8gAFAoegAFAqEgAAyr3IAAhfIAAhQIEOhkIAABkIkOBQIEOhQIAABaIkOBVIEOhVIAABfIkOBfgAAywKIAAgyIAAgxIBkAAIhkAxIBkgxICqAAIkOBjIEOhjIAABjIkOBkgAFAxtg");
	this.shape_11.setTransform(469.1,270.9);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#000000").ss(2,1,1).p("AHFyXIAABpIAABnIAABhIAABOIAABcIAABpIAABiIAABRIAAAdIBJAAIAAHfIwbAAIAAnfILEAAIAAhkIAAhxIAAhfIAAhLIAAhrIAAhdIEOhkAHF2zIAABjIAABaIAABfAHF4XIAABkAC33lIAAgyIBjAAICrAAAC30AIAAhQIAAhjIAAgyIBjgyAC3yhIAAhfIEOhQAC3w4IAAhpIEOhVAC3CiIAAhDAC3FBIAAhTIAAhMIDuhDAC3GbIAAhaIEOhVAC3LFIAAhJIAAhLIAAg/IAAhXIEOhVAC1NDIAAg3IAAhHIACAAIEOhYAC1OdIAAhaIEQhpIAABagAGFmDIBAAAAGFmDIBAgdAHFChIAABLIAABaIAABSIAABLIAABJIAABBIAAAsIAABBAHFBfIAABCAC1MMIC6hHIBWgsAC3mDIDOAAAC3w4IEOhfAC32zIEOhkAC31QIEOhjAC3pYIEOhkAC3q3IEOhhAC3ttIEOhaAC3sCIEOhkAC3mDIEOhuAC3DuIEOhNAC3nnIEOhsAC3vKIAAhuAC3HyIEOhaAC3J8IEOhQAC3IxIEOhOAHFOiIAABkIAABkIAABkIAABfIAAB1IAAA7IAAA7IiIAAIiIAAIAAhuIAAhuIAAhuIAAhfIAAhkgAHFXdIiIA7AHFQGIkQBpAHFRqIkQBkAHFTOIkQBuAHFUtIkQB9AHFWiIkQB2AC1QLIAAhuAHFM0IAABu");
	this.shape_12.setTransform(455.8,303.4);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AE9YYICIg7IAAA7gAC1YYIEQh2IAAA7IiIA7gAC1YYIAAhuIAAhuIAAhuIAAhfIAAhkIAAhuIEQhpIAABuIkQBpIEQhpIAABkIkQBpIEQhpIAABkIkQBkIEQhkIAABkIkQBuIEQhuIAABfIkQB9IEQh9IAAB1IkQB2gAHFTOgAHFOigAC1NDIAAg3IC6hHIBWgsIAABBIkQBpIEQhpIAABaIkQBpgAC1LFIACAAIAAhJIAAhLIAAg/IAAhXIAAhaIAAhTIEOhNIAABLIkOBVIEOhVIAABaIkOBVIEOhVIAABSIkOBaIEOhaIAABLIkOBOIEOhOIAABJIkOBQIEOhQIAABBIkOBYIEOhYIAAAsIhWAsIi6BHgAHFLagAHFFGgAC3CiIDuhDIjuBDIAAhDIDuAAIAgAAIAABCIkOBNgAHFDsgAoNBcIAAnfILEAAIAAhkIEOhsIAABiIkOBuIEOhuIAABRIhAAdIBAgdIAAAdIhAAAIBAAAIBJAAIAAHfgAGFmDIjOAAgAC3pYIAAhfIAAhLIAAhrIAAhdIEOhkIAABnIkOBaIEOhaIAABhIkOBkIEOhkIAABOIkOBhIEOhhIAABcIkOBkIEOhkIAABpIkOBsgAHFnxgAHFtmgAHFvHgAC3w4IEOhfIAABpIkOBkgAC3yhIAAhfIAAhQIAAhjIAAgyIAAgyIBjAAICrAAIkOBkIEOhkIAABkIkOBjIEOhjIAABjIkOBQIEOhQIAABaIkOBVIEOhVIAABfIkOBfgAC33lIBjgygAHFz2gAHF1QgAHF2zgAHF4Xg");
	this.shape_13.setTransform(455.8,303.4);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#000000").ss(2,1,1).p("AFA6KIAABkIAABjIAABaIAABfIAABpIAABnIAABhIAABOIAABcIAABpIAABiIAABRIAAAdIBJAAIAAHkIhJAAIggAAIjuAAIjDAAIj3AAIAAnkID3AAIDDAAIAAhkIAAhxIAAhfIAAhLIAAhrIAAhdIAAhuIAAhpIAAhfIAAhQIAAhjIAAgyIAAgyIBkAAgAAy5YIBkgyAAyAvIAAhBAAyDOIAAhTIAAhMIDuhBAAyF/IAAhXIAAhaIEOhVIAABaIAABSIAABLIAABJIAAAdAAyIJIACgBIgCgyAA0IOIAAgGAAyIJIAAgzIAAgYIAAg/IEOhaAA0JSIAAgBIAAhDICrg2IBhgfAA0JlIAAgTIgCAAIACgBAAyJSIAAhJAAyN/IAAhHIACAAIAAhJIAAhLIAAg/IEOhaIAABLIAABJIAABBIAAAsIAABBIAABaIAABuIAABkIAABkIAABkIAABfIAAB1IAAA7IiIA7IiIAAIAAhuIAAhuIAAhuIAAhfIAAhkIAAhuIAAhaIAAg3IC7hHIBVgsAiRn2IAAHkAEAn2IBAAAAEAn2IBAgdAFAgSIAABAIAABLAFCHWIAAA1AAyn2IDOAAAAy0UIEOhVAAyyrIEOhfAAy4mIEOhkAAy3DIEOhjAAy1zIEOhQAAyrLIEOhkAAysqIEOhhAAyvgIEOhaAAyt1IEOhkAAyw9IEOhkAAyn2IEOhuAAyB7IEOhNAAypaIEOhsAAyEoIEOhVAAyG+IEOhOAA0M4IEOhYAA0KkIEOhOAA0LvIEOhQAFCZQIAAA7IiIAAAFCOnIkQBpAFCYVIkQB2AFCWgIkQB9AFCVBIkQBuAFCTdIkQBkAFCR5IkQBpAAyR+IEQhpAAyO2IEQhp");
	this.shape_14.setTransform(469.1,304.9);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AC6aLIiIAAIEQh2IAAA7IiIA7ICIg7IAAA7gAAyYdIEQh9IAAB1IkQB2gAAyWvIEQhuIAABfIkQB9gAFCYVgAAyVBIEQhkIAABkIkQBugAAyTiIAAhkIAAhuIAAhaIEQhpIAABaIkQBpIEQhpIAABuIkQBpIEQhpIAABkIkQBpIEQhpIAABkIkQBkgAFCR5gAAyN/IC7hHIBVgsIAABBIkQBpgAAyM4IACAAIAAhJIEOhQIkOBQIAAhLIAAg/IEOhaIAABLIkOBOIEOhOIAABJIAABBIkOBYIEOhYIAAAsIhVAsIi7BHgAFCLggAA0JSIgCAAIACgBIAAABIAAgBIgCABIAAhJIACgBIAAAGICrg2IBhgfIAAAdIACAAIAAA1IkOBagAA0JRIAAhDgAA0IIIgCgyIACAyIgCABIAAgzIAAgYIEOhOIAABJIhhAfIirA2gAA0IIgAAyF/IAAhXIAAhaIAAhTIAAhMIAAhBIjDAAIAAnkIAAHkIj3AAIAAnkID3AAIDDAAIEOhuIAABRIhAAdIjOAAIDOAAIBAAAIhAAAIBAgdIAAAdIBJAAIAAHkIhJAAIggAAIAgAAIAABAIkOBNIEOhNIAABLIkOBVIEOhVIAABaIkOBVIEOhVIAABSIkOBaIEOhaIAABLIkOBOgAAyAvIDuhBgAEggSIjuAAgAFADTgAFAAugAFAgSgAAypaIAAhxIAAhfIAAhLIAAhrIEOhaIAABhIkOBkIEOhkIAABOIkOBhIEOhhIAABcIkOBkIEOhkIAABpIkOBsIEOhsIAABiIkOBugAFAoTgAFArGgAFAvZgAAyw9IAAhuIAAhpIEOhVIAABfIkOBfIEOhfIAABpIkOBkIEOhkIAABnIkOBagAAy1zIAAhQIAAhjIAAgyIBkgyICqAAIkOBkIEOhkIAABkIkOBjIEOhjIAABjIkOBQIEOhQIAABaIkOBVgAAy6KIBkAAIhkAygAFA6Kg");
	this.shape_15.setTransform(469.1,304.9);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#000000").ss(2,1,1).p("AB94mIAABjIAABaIAABfIAABpIAABnIAABhIAABOIAABcIAABpIAABiIAABRIAAAdIBJAAIAAHbImGAAIAAgKIgFAAAB96KIAABkAiP4mIAAgyIAAgyIBkAAICoAAAiP5YIBkgyAiP3DIAAhjIEMhkAiP0UIAAhfIAAhQIEMhjAiPvgIAAhdIAAhuIAAhpIEMhVAiPsqIAAhLIAAhrIEMhaAjAn2IAxAAIAAhkIAAhxIAAhfIEMhhAjFn2IAFAAIAAHRAiPDOIAAhTIAAhMIAAhBAiPG+IAAg/IAAhXIAAhaIEMhVIAABaIAABSIAABLIAABJIAABBAiPM4IAAhJIAAhLIAAg/IAAhXIAAhQIEMhOAiRO2IAAg3IAAhHIACAAIEMhYIAAAsIAABBIAABaIkOBpIAAhaIEOhpAA9n2IBAAAAA9n2IBAgdAiPIOICrg4IAFgCIBcgbAB9AuIAABLAiRN/IC5hHIBVgsAB9KfIAABBAB9JWIAABJAB9ImIAAAwAB9gSIAABAAiPn2IDMAAAiPAvIDshBAiPyrIEMhfAiP1zIEMhQAiPrLIEMhkAiPt1IEMhkAiPw9IEMhkAiPn2IEMhuAiPB7IEMhNAiPpaIEMhsAiPF/IEMhaAiPEoIEMhVAiPKkIEMhOAiPLvIEMhQAiPJlIEMhaAB9VBIAABfIAAB1IAAA7IiGA7IiIAAIAAhuIAAhuIAAhuIAAhfIAAhkIAAhuAB9TdIAABkIkOBuAB9R5IAABkIkOBkAB9QVIAABkIkOBpAB9ZQIAAA7IiGAAAB9YVIkOB2AB9WgIkOB9AiRR+IEOhpAB9OnIAABu");
	this.shape_16.setTransform(488.6,294.9);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgJaLIiIAAIEOh2IAAA7IiGA7ICGg7IAAA7gAiRaLIAAhuIAAhuIAAhuIAAhfIAAhkIAAhuIEOhpIAABuIkOBpIEOhpIAABkIkOBpIEOhpIAABkIkOBkIEOhkIAABkIkOBuIEOhuIAABfIkOB9IEOh9IAAB1IkOB2gAiRO2IAAg3IAAhHIACAAIAAhJIAAhLIAAg/IAAhXIAAhQIAAg/IAAhXIAAhaIEMhVIAABaIkMBVIEMhVIAABSIkMBaIEMhaIAABLIkMBOIEMhOIAABJIhcAbIgGACIiqA4ICqg4IAGgCIBcgbIAABBIAAARIkMBaIEMhaIAAAbIAAAwIkMBOIEMhOIAABJIkMBQIEMhQIAABBIkMBYIEMhYIAAAsIhVAsIi5BHIC5hHIBVgsIAABBIkOBpIEOhpIAABaIkOBpgAiPB7IAAhMIAAhBIDsAAIAgAAIAABAIkMBNIEMhNIAABLIkMBVgAiPAvIDshBgAB9AugAjAgbIAAgKIgFAAIAAnRIAFAAIAxAAIAAhkIAAhxIAAhfIAAhLIAAhrIAAhdIAAhuIAAhpIAAhfIAAhQIEMhjIAABjIkMBQIEMhQIAABaIkMBVIEMhVIAABfIkMBfIEMhfIAABpIkMBkIEMhkIAABnIkMBaIEMhaIAABhIkMBkIEMhkIAABOIkMBhIEMhhIAABcIkMBkIEMhkIAABpIkMBsIEMhsIAABiIkMBuIDMAAIBAAAIBJAAIAAHbgAjAglIAAnRgAA9n2IBAgdIAAAdgAiPn2IEMhuIAABRIhAAdgAA9n2gAiPn2gAiP4mIAAgyIAAgyIBkAAIhkAyIBkgyICoAAIkMBkIEMhkIAABkIkMBjgAB96Kg");
	this.shape_17.setTransform(488.6,294.9);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#000000").ss(2,1,1).p("Ago5JIAABjIAABaIAABfIAABpIAABnIAABhIAABOIAABcIAABpIAABiIAABuIC6AAAgo6tIAABkAk25JIAAgyIAAgyIBjAAICrAAAk257IBjgyAk22WIAAhQIAAhjIEOhkAk2wDIAAhdIAAhuIAAhpIAAhfIEOhQAk2uYIAAhrIEOhaAk2p9IAAhxIAAhfIAAhLIEOhkAk2g1IhSAAIAAnkIBSAAIAAhkIEOhsAk2AMIAAhBAk2FcIAAhXIAAhaIAAhTIAAhMIDuhBIjuAAAk2HmIAAhLIAAg/IEOhaIAABLIAABJIAABBIAAAiIAAA1IAABLIAABJIAABBIAAAsAk2IxIAAhLIEOhQAk2LHIAAg/IAAhXICyg4Ak2MSIAAhLIEOhOAk4PZIAAg3IAAhHIACAAIAAhJIEOhQAk4QzIAAhaIEQhpIAABagAgog1IggAAAgog1IAABAIAABLIAABaIAABSACSg1Ii6AAACSg1IAAnkID3AAIAAHkgAiRH5IBpgiAk4OiIC6hHIBWgsIAABBAk2oZIEOAAAk203IEOhVAk2zOIEOhfAk23mIEOhjAk2ruIEOhkAk2tNIEOhhAk2xgIEOhkAk2oZIEOhuAk2BYIEOhNAk2CrIEOhVAk2GbIEOhOAk2EFIEOhVAk2NbIEOhYAk2KIIEOhaAgoScIAABkIAABkIAABfIAAB1IAAA7IAAA7IiIAAIiIAAIAAhuIAAhuIAAhuIAAhfIAAhkIEQhpIAABkIkQBpAgoZzIiIA7AgoXDIkQB9AgoY4IkQB2AgoUAIkQBkAgoVkIkQBuAgoPKIAABuAk4ShIAAhu");
	this.shape_18.setTransform(505.3,288.4);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AiwauICIg7IAAA7gAk4auIEQh2IAAA7IiIA7gAk4ZAIEQh9IAAB1IkQB2gAk4XSIEQhuIAABfIkQB9gAgoY4gAk4VkIAAhfIAAhkIAAhuIAAhaIAAg3IAAhHIACAAIAAhJIAAhLIAAg/IAAhXIAAhLIAAhLIAAg/IAAhXIAAhaIAAhTIAAhMIAAhBIhSAAIAAnkIBSAAIAAhkIAAhxIAAhfIAAhLIAAhrIAAhdIAAhuIAAhpIAAhfIAAhQIEOhjIAABjIkOBQIEOhQIAABaIkOBVIEOhVIAABfIkOBfIEOhfIAABpIkOBkIEOhkIAABnIkOBaIEOhaIAABhIkOBkIEOhkIAABOIkOBhIEOhhIAABcIkOBkIEOhkIAABpIkOBsIEOhsIAABiIkOBuIEOAAIkOAAIEOhuIAABuIC6AAID3AAIAAHkIj3AAIAAnkIAAHkIi6AAIggAAIAgAAIAABAIkOBNIEOhNIAABLIkOBVIEOhVIAABaIkOBVIEOhVIAABSIkOBaIEOhaIAABLIkOBOIEOhOIAABJIkOBQIEOhQIAABBIhoAiIAMAAIBcAAIAAA1IkOBaIEOhaIAABLIkOBOIEOhOIAABJIkOBQIEOhQIAABBIkOBYIEOhYIAAAsIhWAsIi6BHIC6hHIBWgsIAABBIkQBpIEQhpIAABaIkQBpIEQhpIAABuIkQBpIEQhpIAABkIkQBpIEQhpIAABkIkQBkIEQhkIAABkIkQBugAk2IxICyg4gAk2AMIDuhBgAhIg1IjuAAgAgoVkgAgoQ4gAgoIugAgoCwgAgoALgAk25JIAAgyIAAgyIBjAAIhjAyIBjgyICrAAIkOBkIEOhkIAABkIkOBjgAgo6tg");
	this.shape_19.setTransform(505.3,288.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_3}]},116).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.shape_1},{t:this.shape},{t:this.instance_3}]},1).to({state:[{t:this.shape_3},{t:this.shape_2}]},1).to({state:[{t:this.shape_5},{t:this.shape_4}]},2).to({state:[{t:this.shape_7},{t:this.shape_6}]},2).to({state:[{t:this.shape_9},{t:this.shape_8}]},2).to({state:[{t:this.shape_11},{t:this.shape_10}]},2).to({state:[{t:this.shape_13},{t:this.shape_12}]},2).to({state:[{t:this.shape_15},{t:this.shape_14}]},2).to({state:[{t:this.shape_17},{t:this.shape_16}]},2).to({state:[{t:this.shape_19},{t:this.shape_18}]},2).to({state:[{t:this.shape_19},{t:this.shape_18}]},2).wait(9));
	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(116).to({_off:false},0).wait(14).to({x:543.1},0).wait(1).to({x:515.4},0).wait(1).to({x:487.8},0).wait(1).to({x:487.7},0).to({_off:true},1).wait(27));

	// Layer 3
	this.instance_4 = new lib.Symbol16();
	this.instance_4.setTransform(643.7,320.2,1,1,0,0,0,52.2,114.3);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(129).to({_off:false},0).wait(1).to({x:616},0).wait(1).to({x:588.3},0).wait(1).to({x:560.7},0).wait(20).to({_off:true},1).wait(8));

	// Wedge
	this.instance_5 = new lib.Symbol13();
	this.instance_5.setTransform(39.8,430.3,1,1,0,0,0,24.7,29.5);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(100).to({_off:false},0).wait(1).to({x:36.7,y:415.4},0).wait(1).to({x:33.7,y:400.5},0).wait(1).to({x:30.7,y:385.6},0).wait(1).to({x:27.7,y:370.7},0).wait(1).to({x:24.7,y:355.9},0).wait(2).to({y:381.9},0).wait(1).to({y:407.9},0).wait(1).to({y:433.9},0).wait(1).to({y:459.9},0).wait(1).to({y:485.9},0).to({_off:true},1).wait(49));

	// Inclined Plane
	this.instance_6 = new lib.Symbol8();
	this.instance_6.setTransform(288.2,484.8,1,1,0,0,0,184.2,77.3);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(36).to({_off:false},0).wait(1).to({y:478.3},0).wait(1).to({y:471.8},0).wait(1).to({y:465.4},0).wait(1).to({y:458.9},0).wait(1).to({y:452.4},0).wait(1).to({y:445.9},0).wait(1).to({y:439.4},0).wait(1).to({y:433},0).wait(1).to({y:426.5},0).wait(1).to({y:420},0).wait(1).to({y:413.5},0).wait(1).to({y:407},0).wait(1).to({y:400.6},0).wait(1).to({y:394.1},0).wait(1).to({y:387.6},0).wait(1).to({y:381.1},0).wait(1).to({y:374.6},0).wait(1).to({y:368.2},0).wait(1).to({y:361.7},0).wait(1).to({y:355.2},0).wait(1).to({y:348.7},0).wait(1).to({y:342.2},0).wait(1).to({y:335.8},0).wait(1).to({y:329.3},0).wait(1).to({y:322.8},0).wait(30).to({y:277.9},0).wait(1).to({y:233},0).wait(1).to({y:188.2},0).wait(1).to({y:143.3},0).wait(1).to({y:98.4},0).wait(1).to({y:53.6},0).wait(1).to({y:8.7},0).wait(1).to({y:-36.2},0).wait(1).to({y:-81.1},0).to({_off:true},1).wait(61));

	// Weight
	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#000000").ss(3,1,1).p("AAh1xMAAAAg8AspLeIZTAAIAAKUI5TAAg");
	this.shape_20.setTransform(652,316.5);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AspFJIAAqRIZSAAIAAKRg");
	this.shape_21.setTransform(652,423);

	this.instance_7 = new lib.Symbol7();
	this.instance_7.setTransform(652,316.6,1,1,0,0,0,81,139.5);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_21},{t:this.shape_20}]}).to({state:[{t:this.instance_7}]},28).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[]},1).wait(61));
	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(28).to({_off:false},0).wait(1).to({regY:139.4,x:625.9,y:298},0).wait(1).to({x:599.7,y:279.6},0).wait(1).to({x:573.6,y:261.2},0).wait(1).to({x:547.4,y:242.7},0).wait(1).to({x:521.3,y:224.3},0).wait(1).to({x:495.1,y:205.9},0).wait(1).to({x:469,y:187.5},0).wait(1).to({regY:139.5,y:187.6},0).wait(1).to({regY:139.4,y:174.1},0).wait(1).to({y:160.8},0).wait(1).to({y:147.5},0).wait(1).to({y:134.2},0).wait(1).to({y:120.9},0).wait(1).to({y:107.6},0).wait(1).to({y:94.3},0).wait(1).to({y:81},0).wait(1).to({y:67.6},0).wait(1).to({y:54.3},0).wait(1).to({y:41},0).wait(1).to({y:27.7},0).wait(1).to({y:14.4},0).wait(1).to({y:1},0).wait(1).to({y:-12.3},0).wait(1).to({y:-25.6},0).wait(1).to({y:-38.9},0).wait(1).to({y:-52.2},0).wait(1).to({y:-65.5},0).wait(1).to({y:-78.9},0).wait(1).to({y:-92.2},0).wait(1).to({y:-105.5},0).wait(1).to({y:-118.8},0).wait(1).to({y:-132.1},0).wait(1).to({y:-145.5},0).wait(30).to({y:-190.3},0).wait(1).to({y:-235.2},0).wait(1).to({y:-280.1},0).wait(1).to({y:-325},0).wait(1).to({y:-369.8},0).wait(1).to({y:-414.7},0).wait(1).to({y:-459.6},0).wait(1).to({y:-504.5},0).wait(1).to({y:-549.4},0).to({_off:true},1).wait(61));

	// Pully
	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#000000").ss(3,1,1).p("ADIAAQAABTg7A6Qg7A7hSAAQhRAAg7g7Qg7g6AAhTQAAhRA7g7QA7g7BRAAQBSAAA7A7QA7A7AABRg");
	this.shape_22.setTransform(584,175);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("#000000").ss(2,1,1).p("ALLAAQAAEojSDRQjRDSkoAAQknAAjRjSQjSjRAAkoQAAkmDSjSQDRjREnAAQEoAADRDRQDSDSAAEmg");
	this.shape_23.setTransform(583.9,177.5);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("An4H5QjRjRgBkoQABkmDRjSQDSjSEmAAQEoAADRDSQDSDSgBEmQABEojSDRQjRDSkogBQkmABjSjSgAiLilQg7A7ABBTQgBBRA7A6QA7A6BRAAQBTAAA6g6QA6g6AAhRQAAhTg6g7Qg6g7hTABQhRgBg7A7g");
	this.shape_24.setTransform(583.9,177.5);

	this.instance_8 = new lib.Symbol6();
	this.instance_8.setTransform(583.9,177.5,1,1,0,0,0,71.5,71.5);
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_24},{t:this.shape_23},{t:this.shape_22}]}).to({state:[{t:this.instance_8}]},28).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_8}]},1).to({state:[]},1).wait(61));
	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(28).to({_off:false},0).wait(1).to({x:557.8,y:159},0).wait(1).to({x:531.6,y:140.6},0).wait(1).to({x:505.5,y:122.2},0).wait(1).to({x:479.3,y:103.7},0).wait(1).to({x:453.2,y:85.3},0).wait(1).to({x:427,y:66.9},0).wait(1).to({x:400.9,y:48.5},0).wait(1).to({y:31.7},0).wait(1).to({y:25.3},0).wait(1).to({y:18.8},0).wait(1).to({y:12.3},0).wait(1).to({y:5.8},0).wait(1).to({y:-0.7},0).wait(1).to({y:-7.1},0).wait(1).to({y:-13.6},0).wait(1).to({y:-20.1},0).wait(1).to({y:-26.6},0).wait(1).to({y:-33.1},0).wait(1).to({y:-39.5},0).wait(1).to({y:-46},0).wait(1).to({y:-52.5},0).wait(1).to({y:-59},0).wait(1).to({y:-65.5},0).wait(1).to({y:-71.9},0).wait(1).to({y:-78.4},0).wait(1).to({y:-84.9},0).wait(1).to({y:-91.4},0).wait(1).to({y:-97.9},0).wait(1).to({y:-104.3},0).wait(1).to({y:-110.8},0).wait(1).to({y:-117.3},0).wait(1).to({y:-123.8},0).wait(1).to({y:-130.3},0).wait(30).to({y:-175.1},0).wait(1).to({y:-220},0).wait(1).to({y:-264.9},0).wait(1).to({y:-309.8},0).wait(1).to({y:-354.6},0).wait(1).to({y:-399.5},0).wait(1).to({y:-444.4},0).wait(1).to({y:-489.3},0).wait(1).to({y:-534.2},0).to({_off:true},1).wait(61));

	// Layer 1
	this.instance_9 = new lib.Symbol11();
	this.instance_9.setTransform(329.4,8.5,1,1,0,0,0,0,87.5);
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(90).to({_off:false},0).wait(1).to({y:-36.3},0).wait(1).to({y:-81.2},0).wait(1).to({y:-126.1},0).wait(1).to({y:-171},0).wait(1).to({y:-215.8},0).wait(1).to({y:-260.7},0).wait(1).to({y:-305.6},0).wait(1).to({y:-350.5},0).wait(1).to({y:-395.4},0).to({_off:true},1).wait(61));

	// String
	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f().s("#000000").ss(2,1,1).p("AAABRIAAih");
	this.shape_25.setTransform(329.4,39.9);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("#000000").ss(2,1,1).p("AAAhwIAADh");
	this.shape_26.setTransform(329.4,36.7);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f().s("#000000").ss(2,1,1).p("AAAiQIAAEh");
	this.shape_27.setTransform(329.4,33.5);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f().s("#000000").ss(2,1,1).p("AAAivIAAFg");
	this.shape_28.setTransform(329.4,30.4);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f().s("#000000").ss(2,1,1).p("AAAjPIAAGf");
	this.shape_29.setTransform(329.4,27.2);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f().s("#000000").ss(2,1,1).p("AAAjvIAAHf");
	this.shape_30.setTransform(329.4,24);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f().s("#000000").ss(2,1,1).p("AAAkPIAAIf");
	this.shape_31.setTransform(329.4,20.8);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f().s("#000000").ss(2,1,1).p("AAAkuIAAJd");
	this.shape_32.setTransform(329.4,17.7);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f().s("#000000").ss(2,1,1).p("AAAlOIAAKd");
	this.shape_33.setTransform(329.4,14.5);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f().s("#000000").ss(2,1,1).p("AAAluIAALd");
	this.shape_34.setTransform(329.4,11.3);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f().s("#000000").ss(2,1,1).p("AAAmOIAAMd");
	this.shape_35.setTransform(329.4,8.2);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f().s("#000000").ss(2,1,1).p("AAAmtIAANb");
	this.shape_36.setTransform(329.4,5);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f().s("#000000").ss(2,1,1).p("AAAnNIAAOb");
	this.shape_37.setTransform(329.4,1.8);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f().s("#000000").ss(2,1,1).p("AAAntIAAPb");
	this.shape_38.setTransform(329.4,-1.4);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f().s("#000000").ss(2,1,1).p("AAAoNIAAQb");
	this.shape_39.setTransform(329.4,-4.5);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f().s("#000000").ss(2,1,1).p("AAAosIAARZ");
	this.shape_40.setTransform(329.4,-7.7);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f().s("#000000").ss(2,1,1).p("AAApMIAASZ");
	this.shape_41.setTransform(329.4,-10.9);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f().s("#000000").ss(2,1,1).p("AAApsIAATZ");
	this.shape_42.setTransform(329.4,-14.1);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f().s("#000000").ss(2,1,1).p("AAAqMIAAUZ");
	this.shape_43.setTransform(329.4,-17.2);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f().s("#000000").ss(2,1,1).p("AAAqrIAAVX");
	this.shape_44.setTransform(329.4,-20.4);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f().s("#000000").ss(2,1,1).p("AAArLIAAWX");
	this.shape_45.setTransform(329.4,-23.6);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f().s("#000000").ss(2,1,1).p("AAArrIAAXX");
	this.shape_46.setTransform(329.4,-26.7);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f().s("#000000").ss(2,1,1).p("AAAsKIAAYV");
	this.shape_47.setTransform(329.4,-29.9);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f().s("#000000").ss(2,1,1).p("AAAsqIAAZV");
	this.shape_48.setTransform(329.4,-33.1);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f().s("#000000").ss(2,1,1).p("AAAtKIAAaV");
	this.shape_49.setTransform(329.4,-36.3);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f().s("#000000").ss(2,1,1).p("AAANrIAA7V");
	this.shape_50.setTransform(329.4,-39.4);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f().s("#000000").ss(2,1,1).p("AAAtqIAAbV");
	this.shape_51.setTransform(329.4,-31.4);
	this.shape_51._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_25}]},36).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50,p:{y:-39.4}}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_50,p:{y:8.5}}]},1).to({state:[]},23).to({state:[]},10).wait(61));
	this.timeline.addTween(cjs.Tween.get(this.shape_51).wait(62).to({_off:false},0).wait(1).to({y:-23.4},0).wait(1).to({y:-15.4},0).wait(1).to({y:-7.5},0).wait(1).to({y:0.5},0).to({_off:true},1).wait(94));

	// Layer 2
	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f().s("#FFFFFF").ss(0.7,1,1).p("AApADIhRAAIAAgFIBHAA");
	this.shape_52.setTransform(307,294.7);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f().s("#FFFFFF").ss(1,1,1).p("AA8AVIAAgaIESAAIAAAKAkrgUIFnAAIAAAPAFeAMIAAAJIgQAAIAAgQIAQAAAFOAVIkSAAImZAA");
	this.shape_53.setTransform(267.8,293.8);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f().s("#000000").ss(1,1,1).p("AIJBoIvnBXIgql9");
	this.shape_54.setTransform(277.2,284.2);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#FFFFFF").s().p("AnMDJQgNgDgHgPQgEgIgCgTQgDgQACgLIADgRQABgGgDgLQgDgMAAgEIABgUIgEgoQgJhOAEgoQACgggBgIIgEgbQgCgQAHgKQAGgHAKgCQAKgBAIAGQAKAHAFAZQAFAZANAsQAOAwAFAVQATBRgWA6QAUANADANQADAJgEAHIFpAAIAAAPIEQAAIAAAMIAAAQIkQAAIAAgcIAAAcImbAAQgGAEgHAAIgHgBgADzDGIAAgQIAQAAIAAAHIAAAJgAFWC9IhTAAIAAgHIBJAAQgEgGAAgIQgBgPANgIQgSABgYgEQgOgDgbgIIg0gPQgOgEgGgGQgIgHABgMQABgLAIgGQANgKAdAKIAkALQAgAKAUACQAVADAogBQA7ADAxAkQALAIACAGQAEAHgCAIQgBAIgGAFQgIAIgXACIhhAGIgHAAQgLAAgGgDg");
	this.shape_55.setTransform(276.9,276.1);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f().s("#000000").ss(1,1,1).p("AIbhKIvJEDIhslx");
	this.shape_56.setTransform(276.5,301.7);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f().s("#FFFFFF").ss(1,1,1).p("ABCAVIAAgaIESAAIAAAKAlWgUIGYAAIAAAPAFkAMIAAAJIgQAAIAAgQIAQAAAFUAVIkSAAImlAA");
	this.shape_57.setTransform(267.1,293.8);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#FFFFFF").s().p("AF3DHQgFgDgCgGQgNAAgGgDIhUAAIAAgHIBKAAQgEgGgBgIQgBgPAOgIQgTABgXgEQgPgDgbgIIgzgPQgPgEgGgGQgHgHABgMQAAgLAJgGQANgKAdAKIAkALQAfAKAVACQAUADApgBQA7ADAwAkQALAIADAGQADAHgBAIQgCAIgFAFQgHAHgSACIgBABQgEADgIADIgdAKQgIADgIAAIgWABQgNAAgIgFgAnLDGQgJAAgGgHQgGgGgDgSQgHgkgDgZIgDg7IgEgjQgCgSAAgqQABgogCgVQgEgbAAgNQgBgWAIgOQAHgNALgEQAMgEAKAIQAKAHAAANQAAAIgGAPQgCAKAEAaQADAVgBArQAAArACASIAEAaQACAQAAAgQABAaAHAgIADAPIGaAAIAAAPIEQAAIAAAMIAAAQIkQAAIAAgcIAAAcImnAAQgFACgGAAIgCAAgAD5DEIAAgQIAQAAIAAAHIAAAJg");
	this.shape_58.setTransform(276.2,276.3);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f().s("#000000").ss(1,1,1).p("AmaCbIirlYAJGjTIuNGn");
	this.shape_59.setTransform(271.1,315.9);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f().s("#FFFFFF").ss(1,1,1).p("AlcgUIGgAAIAAAPABEAVIAAgaIESAAIAAAKIAQAAAFmAMIAAAJIgQAAIAAgQAFWAVIkSAAImpAA");
	this.shape_60.setTransform(267,293.8);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#FFFFFF").s().p("AndDNQgMgBgGgKQgGgKAEgZQAGgigCgXIgEggQgBgQABgfIAEhwQABgbgCgNIgGgXQgEgPAAgJQABgOAIgHQAIgIAMABQANACAGAKQADAFABAIIABAOIAHAYQADAOgBAbIgFBoQgBAiABARIAEAmQACAagDAeIGiAAIAAAPIEQAAIAAAMIAQAAIBKAAQgEgGgBgIQgBgPAOgIQgTABgXgEQgPgDgbgIIgzgPQgPgEgGgGQgHgHABgMQAAgLAJgGQANgKAdAKIAkALQAfAKAVACQAUADApgBQA7ADAwAkQALAIADAGQADAHgBAIQgCAIgFAFQgHAGgSADIgBABQgEADgIADIgdAKQgIADgIAAIgWABQgNAAgIgFQgFgDgCgGQgNAAgGgDIhUAAIAAgHIAAAHIAAAJIgQAAIAAgQIAAAQIkQAAIAAgcIAAAcImrAAIgFAHQgHAGgKAAIgCAAg");
	this.shape_61.setTransform(276.5,276.7);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f().s("#000000").ss(1,1,1).p("AmCCbIjlk2AJojTIuNGn");
	this.shape_62.setTransform(267.7,315.9);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f().s("#FFFFFF").ss(1,1,1).p("AlKgUIGUAAIAAAPIESAAIAAAKIAQAAABKAVIAAgaAFsAMIAAAJIgQAAIAAgQAFcAVIkSAAIm1AAIAAgB");
	this.shape_63.setTransform(266.4,293.8);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#FFFFFF").s().p("AFsDHQgEgEgDgFQgNAAgGgDIhUAAIAAgIIBKAAQgEgFgBgJQgBgPAOgHQgTABgXgFQgPgDgbgIIgzgPQgPgEgGgGQgHgHABgLQAAgMAJgGQANgJAdAJIAkALQAfAKAVADQAUACApgBQA7ADAwAkQALAJADAFQADAHgBAIQgCAIgFAGQgHAGgSADIgBAAQgEAEgIACIgdALQgIACgIABIgWABQgNAAgIgFgADuDDIAAgQIAAAQIkQAAIAAgbIEQAAIAAALIAQAAIAAAIIAAAIgAgiDDIm2AAIAAgBQgLgCgGgJQgEgIABgNIADgWQABgLgEgeQgCgTACgfIACgxQAAgWgEg/QgEg2ACggQABgOAEgHQAHgLANAAQAMAAAIALQAGAIAAARIgBAuIAFBEQADAqgBAYIgDAnQgCAWACAQIAEAeIgCAeIAAADIGWAAIAAAPIAAAbgAD+C7g");
	this.shape_64.setTransform(277.3,276.4);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f().s("#000000").ss(1,1,1).p("AlpCTIkXkJAKBjTIuNGn");
	this.shape_65.setTransform(265.2,315.9);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f().s("#FFFFFF").ss(1,1,1).p("AlNgUIGXAAIAAAPABKAVIAAgaIESAAIAAAKIAQAAAFsAMIAAAJIgQAAIAAgQAFcAVIkSAAIm1AAIAAAA");
	this.shape_66.setTransform(266.4,293.8);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#FFFFFF").s().p("AFtDIQgFgDgDgGQgNAAgGgDIhTAAIAAgHIAAAHIAAAJIgQAAIAAgQIAAAQIkQAAIAAgcIAAAcIm3AAIAAgBQgLgCgGgJIgCgFIgBgEQgCgIADgHQgBgHAAgJIAAgtQAAgaACgMQADgMgBgGQAAgFgDgJQgCgKAAgUIABh1QAAgagCgMIgCgSQgBgJADgHQAGgMALgCQAOgDAIAJQAJAIACAYQACASAAA3IgBA7QAAAPACAIIAFAPQACALgBAOIgDAZQgGApACAsIAAAOIGZAAIAAAPIEQAAIAAAMIAQAAIBJAAQgEgGAAgIQgBgPANgIQgSABgYgEQgOgDgbgIIg0gPQgOgEgGgGQgIgHABgMQABgLAIgGQANgKAdAKIAkALQAgAKAUACQAVADAogBQA7ADAxAkQALAIACAGQAEAHgCAIQgBAIgGAFQgHAGgRADIgBABQgFADgIADIgdAKQgHADgIAAIgWABQgOAAgHgFg");
	this.shape_67.setTransform(277.3,276.2);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f().s("#000000").ss(1,1,1).p("AlUCXIlCjUAKWjTIuNGn");
	this.shape_68.setTransform(263.1,315.9);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f().s("#FFFFFF").ss(1,1,1).p("AlYgUIGZAAIAAAPABBAVIAAgaIESAAIAAAKIAQAAAFjAMIAAAJIgQAAIAAgQAFTAVIkSAAImjAA");
	this.shape_69.setTransform(267.3,293.8);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#FFFFFF").s().p("AnbDNQgMgBgHgJQgGgJADgRIAGgaIABgeIADgcQAAgLgDgWQgDgWAAgLIAEgcQADgTgCgfIgDgzQAAgigBgHIgEgUQgBgMAEgIQAFgKAMgDQAMgBAJAIQAHAGADAOQADAMABASIAAAeIADA8QABAkgCAWIgDAdQABAMAEAXIAAAgIgGA3IGbAAIAAAPIEQAAIAAALIAQAAIBKAAQgEgGgBgIQgBgPAOgHQgTABgXgFQgPgDgbgIIgzgPQgPgEgGgGQgHgHABgLQAAgMAJgGQANgJAdAJIAkALQAfAKAVADQAUACApgBQA7ADAwAkQALAJADAFQADAHgBAIQgCAIgFAGQgHAGgSACIgBABQgEAEgIACIgdALQgIACgIABIgWABQgNAAgIgFQgFgEgCgGQgNABgGgDIhUAAIAAgIIAAAIIAAAIIgQAAIAAgQIAAAQIkQAAIAAgbIAAAbImkAAIgEAFQgHAGgKAAIgCAAg");
	this.shape_70.setTransform(277.1,276.5);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f().s("#000000").ss(1,1,1).p("AlECcIliibAKnjTIuOGn");
	this.shape_71.setTransform(261.5,315.9);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f().s("#FFFFFF").ss(1,1,1).p("ABCAVIAAgaIESAAIAAAKIAQAAAlWgUIGYAAIAAAPAFUAVIAAgQAFkAMIAAAJIgQAAIkSAAImlAA");
	this.shape_72.setTransform(267.2,293.8);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#FFFFFF").s().p("AFtDHQgFgDgCgGQgNAAgGgDIhUAAIAAgHIBKAAQgEgGgBgIQgBgPAOgIQgTABgXgEQgPgDgbgIIgzgPQgPgEgGgGQgHgHABgMQAAgLAJgGQANgKAdAKIAkALQAfAKAVACQAUADApgBQA7ADAwAkQALAIADAGQADAHgBAIQgCAIgFAFQgHAHgSACIgBABQgEADgIADIgdAKQgIADgIAAIgWABQgNAAgIgFgAnnDFQgJgIgBgQQAAgJAEgSQAHgmgDgmQgGgwABgWIAEggQABgPAAggIAAhWQAAgUAFgIQAIgLANABQAOABAGALQADAGABARIAAAyQABA8gDAlIgCAfIACAbQADAcAAAYQAAAggFAgIGaAAIAAAPIEQAAIAAAMIAQAAIAAAHIAAAJIgQAAIAAgQIAAAQIkQAAIAAgcIAAAcImmAAQgGAFgIABIgEAAQgIAAgGgFgAD/C7g");
	this.shape_73.setTransform(277.2,276.3);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f().s("#000000").ss(1,1,1).p("Ak0CWIl3hcAKsjTIuNGn");
	this.shape_74.setTransform(260.9,315.9);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#FFFFFF").s().p("AFuDGQgFgDgCgGQgNAAgGgDIhUAAIAAgHIBKAAQgEgGgBgIQgBgPAOgIQgTABgXgEQgPgDgbgIIgzgPQgPgEgGgGQgHgHABgMQAAgLAJgGQANgKAdAKIAkALQAfAKAVACQAUADApgBQA7ADAwAkQALAIADAGQADAHgBAIQgCAIgFAFQgHAGgSADIgBABQgEADgIADIgdAKQgIADgIAAIgWABQgNAAgIgFgAndDKQgMgCgFgLQgFgJAEgYQANhAgIhBQgEgZgBgLQgBgMABgXQABg+gEg3QgBgTAEgJQAGgLANgCQAOgBAIALQAGAIABAVIADBQQABAUgBAKIgCAdIAFAfIACAhQACAvgBAVQAAAYgDAUIGZAAIAAAPIEQAAIAAAMIAQAAIAAAHIAAAJIgQAAIAAgQIAAAQIkQAAIAAgcIAAAcImnAAIgBAAQgHAHgKAAIgEAAgAEAC6g");
	this.shape_75.setTransform(277.1,276.4);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f().s("#000000").ss(1,1,1).p("AkvCUImBgYAKxjTIuNGn");
	this.shape_76.setTransform(260.4,315.9);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f().s("#FFFFFF").ss(1,1,1).p("ABDAVIAAgaIESAAIAAAKIAQAAAlVgUIGYAAIAAAPAFVAVIAAgQAFlAMIAAAJIgQAAIkSAAImnAA");
	this.shape_77.setTransform(267.1,293.8);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#FFFFFF").s().p("AFvDGQgEgEgDgGQgNABgGgDIhUAAIAAgIIBKAAQgEgFgBgJQgBgPAOgHQgTABgXgFQgPgDgbgIIgzgPQgPgEgGgGQgHgHABgLQAAgMAJgGQANgJAdAJIAkALQAfAKAVADQAUACApgBQA7ADAwAkQALAJADAFQADAHgBAIQgCAIgFAGQgHAGgSACIgBABQgEAEgIACIgdALQgIACgIABIgWABQgNAAgIgFgAneDKQgIgBgGgGQgGgGgBgHQgCgJAFgPQAIgaACgNQAEgWgEgRIgFgVQgCgIAAgSQABhegFhpQgBgRAFgIQAFgJAMgBQANgCAHAIQAKAJABAcIACCpQAAAYACALIAFAZQACAIAAAZQgBAZgCAHIgDAQIGZAAIAAAPIEQAAIAAALIAQAAIAAAIIAAAIIgQAAIAAgQIAAAQIkQAAIAAgbIAAAbImpAAIgHAFQgGADgGAAIgDAAgAEBC6g");
	this.shape_78.setTransform(277,276.5);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f().s("#000000").ss(1,1,1).p("AkwCSIl/AsAKwjTIuNGn");
	this.shape_79.setTransform(260.5,315.9);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f().s("#FFFFFF").ss(1,1,1).p("ABDAVIAAgaIESAAIAAAKIAQAAAlLgUIGOAAIAAAPAFlAMIAAAJIgQAAIAAgQAFVAVIkSAAImnAA");
	this.shape_80.setTransform(267,293.8);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#FFFFFF").s().p("AFvDHQgFgDgDgGQgMAAgHgDIhTAAIAAgHIBKAAQgFgGAAgIQgBgPANgIQgSABgYgEQgOgDgbgIIg0gPQgOgEgGgGQgIgHABgMQABgLAIgGQANgKAdAKIAkALQAgAKAUACQAVADAogBQA7ADAxAkQALAIACAGQAEAHgCAIQgBAIgGAFQgGAGgSADIgBABQgFADgIADIgdAKQgHADgIAAIgWABQgOAAgHgFgAnZDFQgKgDgEgMQgFgLAFgKQgRgVAHgbIAJgYQADgOAAgQQAAgOgDgxQgCgYgBhFIgBhIQgBgPAEgIQAFgIAKgCQAKgDAIAGQAPAJAAAhIAABIQAAApACAVIADAoQADAmgEAfQgBALABAFIAFAOQADAKgCASIgBAJIGRAAIAAAPIEQAAIAAAMIAQAAIAAAHIAAAJIgQAAIAAgQIAAAQIkQAAIAAgcIAAAcImqAAQgFACgFAAIgGgBgAEBC0g");
	this.shape_81.setTransform(277.1,276.3);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f().s("#000000").ss(1,1,1).p("Ak8CPIlxBuAKuj7IuNGn");
	this.shape_82.setTransform(260.7,319.9);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f().s("#FFFFFF").ss(1,1,1).p("AlRgUIGSAAIAAAPIESAAIAAAKIAQAAABBAVIAAgaAFjAMIAAAJIgQAAIAAgQAFTAVIkSAAImjAA");
	this.shape_83.setTransform(267.3,293.8);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#FFFFFF").s().p("AFvDHQgFgDgDgGQgNAAgGgDIhTAAIAAgHIBJAAQgEgGAAgIQgBgPANgIQgSABgYgEQgOgDgbgIIg0gPQgOgEgGgGQgIgHABgMQABgLAIgGQANgKAdAKIAkALQAgAKAUACQAVADAogBQA7ADAxAkQALAIACAGQAEAHgCAIQgBAIgGAFQgHAGgRADIgBABQgFADgIADIgdAKQgHADgIAAIgWABQgOAAgHgFgAnUDEIgCAAQgNgFgCgPQAAgMgBgGQAAgEgEgHIgDgLQgBgFACgHIAFgMQACgIgBgSIgFg0QgEgfAEgcQAEgUgBgHIgCgNIgEgNQgCgNAAgWQABgagBgJIgCgYQABgPAGgIQAIgIAMAAQAMABAHAJQAFAIABAPIABAiIAAAkIAGAcQADARgDASIgDAUQgBAMACAGIAEANQAFAQgCAhIgDBMIACAOIGUAAIAAAPIAAAcImlAAQgEABgEAAIgIgBgADxDEIAAgQIAAAQIkQAAIAAgcIEQAAIAAAMIAQAAIAAAHIAAAJgAEBC7g");
	this.shape_84.setTransform(277.1,276.3);

	this.instance_10 = new lib.Symbol10();
	this.instance_10.setTransform(260.7,300.8,1,1,0,0,0,68.7,44.9);
	this.instance_10._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52}]},68).to({state:[{t:this.shape_58},{t:this.shape_57},{t:this.shape_52},{t:this.shape_56}]},1).to({state:[{t:this.shape_61},{t:this.shape_60},{t:this.shape_52},{t:this.shape_59}]},1).to({state:[{t:this.shape_64},{t:this.shape_63},{t:this.shape_52},{t:this.shape_62}]},1).to({state:[{t:this.shape_67},{t:this.shape_66},{t:this.shape_52},{t:this.shape_65}]},1).to({state:[{t:this.shape_70},{t:this.shape_69},{t:this.shape_52},{t:this.shape_68}]},1).to({state:[{t:this.shape_73},{t:this.shape_72,p:{x:267.2}},{t:this.shape_52},{t:this.shape_71}]},1).to({state:[{t:this.shape_75},{t:this.shape_72,p:{x:267.1}},{t:this.shape_52},{t:this.shape_74}]},1).to({state:[{t:this.shape_78},{t:this.shape_77},{t:this.shape_52},{t:this.shape_76}]},1).to({state:[{t:this.shape_81},{t:this.shape_80},{t:this.shape_52},{t:this.shape_79}]},1).to({state:[{t:this.shape_84},{t:this.shape_83},{t:this.shape_52},{t:this.shape_82}]},1).to({state:[{t:this.instance_10}]},12).to({state:[{t:this.instance_10}]},1).to({state:[{t:this.instance_10}]},1).to({state:[{t:this.instance_10}]},1).to({state:[{t:this.instance_10}]},1).to({state:[{t:this.instance_10}]},1).to({state:[{t:this.instance_10}]},1).to({state:[{t:this.instance_10}]},1).to({state:[{t:this.instance_10}]},1).to({state:[{t:this.instance_10}]},1).to({state:[]},1).wait(61));
	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(90).to({_off:false},0).wait(1).to({y:255.9},0).wait(1).to({y:211},0).wait(1).to({y:166.2},0).wait(1).to({y:121.3},0).wait(1).to({y:76.4},0).wait(1).to({y:31.6},0).wait(1).to({y:-13.3},0).wait(1).to({y:-58.2},0).wait(1).to({y:-103.1},0).to({_off:true},1).wait(61));

	// Basket 1
	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f().s("#000000").ss(2,1,1).p("AABvfQACE8gCGHQgBFtgBEQIAAKA");
	this.shape_85.setTransform(512.2,286.7);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f().s("#000000").ss(1,1,1).p("AH0E/IvnAAIAAmDIPnj6");
	this.shape_86.setTransform(462,354);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#FFFFFF").s().p("AnyE/IAAmDIPmj6IAAJ9g");
	this.shape_87.setTransform(462,354);

	this.instance_11 = new lib.Symbol4();
	this.instance_11.setTransform(462.5,286.7,1,1,0,0,0,50.5,99.3);
	this.instance_11._off = true;

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f().s("#FFFFFF").ss(1,1,1).p("AgViZIAAAIIAAAxIAABHIAAAJIAABcIAABOIArAAIAAkzg");
	this.shape_88.setTransform(234.8,280.5);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#FFFFFF").s().p("AgTDbQgMgBgGgJQgEgHgBgQQgFgKAAgSQABgbAFgaIABgHIAChJIgFgMQgDgKAAgUIAAhGIAAgZIgGgWQgGgVACgJQADgPALgIQACgNADgGQAFgJAMgCQAMgCAIAHQAGAHACANQAGAEACAHQABAFAAAIIAAANIAAAMQAAAHgBAEIgEAJIAAAIIAAgIIAtAAIAAEzIgtAAIAAhOIAAheIAAgKIAAAJIAAABIAABeIgCAGIgDAKIABA1QAAAdgJAJQgGAGgIAAIgEAAgAAMACIAAhEIAAgxQAAAEgDAFIgBAEIABAEQACAMABAUgAAMAMg");
	this.shape_89.setTransform(231.3,277.5);

	this.instance_12 = new lib.Symbol9();
	this.instance_12.setTransform(278,197.3,1,1,0,0,0,52.5,101.3);
	this.instance_12._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_87},{t:this.shape_86},{t:this.shape_85}]}).to({state:[{t:this.instance_11}]},28).to({state:[{t:this.instance_11}]},1).to({state:[{t:this.instance_11}]},1).to({state:[{t:this.instance_11}]},1).to({state:[{t:this.instance_11}]},1).to({state:[{t:this.instance_11}]},1).to({state:[{t:this.instance_11}]},1).to({state:[{t:this.instance_11}]},1).to({state:[{t:this.instance_11}]},1).to({state:[{t:this.instance_11}]},26).to({state:[{t:this.instance_11}]},1).to({state:[{t:this.instance_11}]},1).to({state:[{t:this.instance_11}]},1).to({state:[{t:this.instance_11}]},1).to({state:[{t:this.instance_11}]},1).to({state:[{t:this.shape_89},{t:this.shape_88},{t:this.instance_11}]},1).to({state:[{t:this.instance_12}]},22).to({state:[{t:this.instance_12}]},1).to({state:[{t:this.instance_12}]},1).to({state:[{t:this.instance_12}]},1).to({state:[{t:this.instance_12}]},1).to({state:[{t:this.instance_12}]},1).to({state:[{t:this.instance_12}]},1).to({state:[{t:this.instance_12}]},1).to({state:[{t:this.instance_12}]},1).to({state:[{t:this.instance_12}]},1).to({state:[]},1).wait(61));
	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(28).to({_off:false},0).wait(1).to({x:436.4,y:268.2},0).wait(1).to({x:410.2,y:249.8},0).wait(1).to({x:384.1,y:231.4},0).wait(1).to({x:357.9,y:212.9},0).wait(1).to({x:331.8,y:194.5},0).wait(1).to({x:305.6,y:176.1},0).wait(1).to({x:279.5,y:157.7},0).wait(1).to({y:147.4},0).wait(27).to({y:156.9},0).wait(1).to({y:166.5},0).wait(1).to({y:176.1},0).wait(1).to({y:185.7},0).wait(1).to({y:195.3},0).wait(1).to({_off:true},22).wait(71));
	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(90).to({_off:false},0).wait(1).to({regY:101.2,y:152.3},0).wait(1).to({y:107.4},0).wait(1).to({y:62.6},0).wait(1).to({y:17.7},0).wait(1).to({y:-27.1},0).wait(1).to({y:-72},0).wait(1).to({y:-116.9},0).wait(1).to({y:-161.8},0).wait(1).to({y:-206.7},0).to({_off:true},1).wait(61));

	// Ball
	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f().s("#000000").ss(1,1,1).p("AEVAAQAABzhRBQQhRBShzAAQhxAAhShSQhRhQAAhzQAAhyBRhRQBShRBxAAQBzAABRBRQBRBRAAByg");
	this.shape_90.setTransform(122,207.3);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#000000").s().p("AjDDEQhRhSAAhyQAAhyBRhRQBRhRByAAQBzAABRBRQBRBRAAByQAAByhRBSQhRBRhzAAQhyAAhRhRg");
	this.shape_91.setTransform(122,207.3);

	this.instance_13 = new lib.Symbol2();
	this.instance_13.setTransform(122,207.3,1,1,0,0,0,27.8,27.8);
	this.instance_13._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_91},{t:this.shape_90}]}).to({state:[{t:this.instance_13}]},13).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_13}]},26).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_13}]},1).to({state:[]},1).wait(49));
	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(13).to({_off:false},0).wait(1).to({x:148.7,y:206.8},0).wait(1).to({x:175.5,y:207.8},0).wait(1).to({x:202.1,y:210.1},0).wait(1).to({x:228.6,y:213.9},0).wait(1).to({x:254.8,y:219.2},0).wait(1).to({x:280.7,y:225.9},0).wait(1).to({x:306.2,y:234.2},0).wait(1).to({x:331.1,y:243.9},0).wait(1).to({x:355.4,y:255.1},0).wait(1).to({x:378.9,y:267.8},0).wait(1).to({x:401.5,y:282.1},0).wait(1).to({x:423.1,y:297.9},0).wait(1).to({x:443.4,y:315.4},0).wait(1).to({x:462.1,y:334.6},0).wait(2).to({x:435.9,y:316.1},0).wait(1).to({x:409.8,y:297.7},0).wait(1).to({x:383.6,y:279.3},0).wait(1).to({x:357.5,y:260.8},0).wait(1).to({x:331.3,y:242.4},0).wait(1).to({x:305.2,y:224},0).wait(1).to({x:279.1,y:205.6},0).wait(28).to({y:213.8},0).wait(1).to({y:222},0).wait(1).to({y:230.2},0).wait(1).to({x:279.2,y:238.5},0).wait(1).to({y:246.7},0).wait(2).to({y:264.7},0).wait(1).to({y:282.7},0).wait(1).to({x:272.1,y:285},0).wait(1).to({x:264.9,y:287.2},0).wait(1).to({x:257.8,y:289.5},0).wait(1).to({x:250.7,y:291.8},0).wait(1).to({x:243.5,y:294},0).wait(1).to({x:236.4,y:296.3},0).wait(1).to({x:229.2,y:298.6},0).wait(1).to({x:229.3},0).wait(1).to({x:215.3,y:303.9},0).wait(1).to({x:201.4,y:309.3},0).wait(1).to({x:187.6,y:314.7},0).wait(1).to({x:173.6,y:320},0).wait(1).to({x:159.7,y:325.4},0).wait(1).to({x:145.9,y:330.8},0).wait(1).to({x:132,y:336.2},0).wait(1).to({x:118,y:341.5},0).wait(1).to({x:104.1,y:346.9},0).wait(1).to({x:90.2,y:352.3},0).wait(1).to({x:76.3,y:357.7},0).wait(1).to({x:76.4},0).wait(1).to({x:71},0).wait(1).to({x:65.6},0).wait(1).to({x:60.2},0).wait(1).to({x:54.8},0).wait(1).to({x:49.4},0).wait(1).to({x:44},0).wait(1).to({x:38.6},0).wait(1).to({x:33.2},0).wait(1).to({x:27.8},0).wait(1).to({y:-30.3},0).wait(1).to({y:35.5},0).wait(1).to({y:101.3},0).wait(1).to({y:167.1},0).wait(1).to({y:232.9},0).wait(1).to({x:27.9,y:298.7},0).wait(2).to({x:27.8,y:324.7},0).wait(1).to({y:350.7},0).wait(1).to({y:376.7},0).wait(1).to({y:402.7},0).wait(1).to({y:428.7},0).to({_off:true},1).wait(49));

	// Hammer
	this.instance_14 = new lib.Symbol1();
	this.instance_14.setTransform(109.4,-25.2,1,1,0,0,0,40.3,109.8);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f().s("#000000").ss(1,1,1).p("AGkoSIh4jMILhgFIiYEMIAEAGIgLAGAN1nXIgHAMIjNFpIhqi1IiTj7AllD9ICMDyImoD1ImLqsIGojzIBuC9IOaoUAI3kXIucIUAn2ACICRD7");
	this.shape_92.setTransform(39.7,93.4);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#000000").s().p("AgLAVQgEgCgDgFIgFgJIgBgCIABgDIADgJIADgEQACgDAGgDIgBgCIALgBIAGABIAGABQAGADACADIADAFQAEAMgHAKIgFAEIgEAEIgNACg");
	this.shape_93.setTransform(107.7,41.3);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#FFFFFF").s().p("AwMA4IGojzIBuC8ICRD8ICMDyImoD1gAllD9IiRj8IOaoSICTD6IiTj6Ih4jNILhgFIiYELIAEAHIgLAGIAHgNIgHANIjNFpIhqi1IucIUgAKbofIACADQgHACgCADIgDAFIgDALIAAACIABADIAFAIQADAFADACIALADIAPgDIAEgDIAEgFQAHgJgEgOIgDgGQgCgDgGgCIgFgCIgGgBIgOABgAn2ABg");
	this.shape_94.setTransform(39.7,93.4);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f().s("#000000").ss(1,1,1).p("ANRpIIgEANIiMGHIiIigIi8jdIiZi0ILUiFIhnEiIAFAFIgJAIAmyB7IC7DeICzDXIl3E7In8pdIF4k6ICNCnIMvqsAI5lUIswKt");
	this.shape_95.setTransform(43.7,103.8);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#000000").s().p("AgCAYIgGgCQgEgBgEgEIgGgHIgCgDIAAgCIACgJIACgGIAHgHIgCgBIANgEQACgBADABIAFABQAHABACACIAEAFQAGANgFAJIgDAGIgEADIgCABIgMAFIgBAAIgCAAg");
	this.shape_96.setTransform(107.6,44);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#FFFFFF").s().p("Au3EOIF4k5ICNCmIC7DeIi7jeIMvqsIC8DdIswKtICzDXIl3E7gAmyB7gAI5lUIi8jdIiZi0ILUiEIhnEiIgEAMIiMGHgAJ7psIgNAEIACABIgHAHIgCAHIgCAKIAAACIACADIAGAHQAEAEAEACIAGABIAFAAIAMgEIACgCIAEgDIADgGQAFgKgGgNIgEgGQgCgCgHgBIgFAAIgEgBIgDAAgANNo7gANRpHIAFAEIgJAIg");
	this.shape_97.setTransform(43.7,103.8);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f().s("#000000").ss(1,1,1).p("AMTqmIgCANIhFGaIiiiGIjgi5Ii2iXIKykBIgzEwIAFAEIgHAJAliDxIDfC6IDUC0Ik5F4Ipdn8IE7l4ICoCOIKssvAIqmFIqtMw");
	this.shape_98.setTransform(49.1,107.5);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#000000").s().p("AgNATIgHgFIgCgDIgBgCIAAgJIABgGIAGgIIgCgCQAEgBAIgFIAGAAIAEgBQAHABACABIAFAFQAIALgDAKIgDAGIgCAEIgCABIgLAHIgFAAIgEABQgEgBgFgEg");
	this.shape_99.setTransform(106.9,41.9);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#FFFFFF").s().p("AtFHbIE7l4ICpCOIKrsvIi2iXIKykBIgzEwIgCANIhFGaIiiiGIjgi5IDgC5IqtMwIDUC0Ik5F4gAiDGrIjei6gAI6qlQgIAFgEABIACACIgGAHIgBAGIABAMIAAACIACACIAIAGQAEADAEABIAGAAIAGgBIAKgGIACgBIADgEIACgHQAEgLgJgMIgFgEQgCgCgGAAIgHAAIgCAAIgEABgAMRqZgAMTqmIAFAEIgHAJg");
	this.shape_100.setTransform(49.1,107.5);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f().s("#000000").ss(1,1,1).p("AK5rwIAAAOIADGfIi3hoIj8iPIjOh1IJ7l1IADE0IAGADIgGALAgPHwIDwCMIjzGpIqsmLID1mpIC/BugAkKFfIITuZAIFmrIoUOb");
	this.shape_101.setTransform(60.3,111.8);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#000000").s().p("AgJAVIgIgEIgDgCIgBgCIgCgLIAAgEQABgDAEgGIgDgBIALgIIAGgCIAEgBQAGgBADABIAFAEQALAKgBAKIgCAGIgCAFIgBABIgKAIIgFACIgEABQgEAAgFgDg");
	this.shape_102.setTransform(109.9,42.5);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#FFFFFF").s().p("Aq+KaID1mpIC/BuID7CRIj7iRIITuZIjOh1IJ7l1IADE0IAAAOIADGfIi3hoIj8iPID8CPIoUObIDwCMIjzGpgAHvrMIgGABIgFACIgLAIIACABQgEAGAAADIgBAGIADALIABACIACACIAJAEQAEADAFAAIAGgBIAEgCIAKgIIACgBIACgFIABgGQABgMgKgKIgFgEIgEAAIgGAAgAK5rwIAGADIgGALg");
	this.shape_103.setTransform(60.3,111.8);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f().s("#000000").ss(1,1,1).p("AIPsjIACANIBMGYIjHhGIkRhhIjdhPIIvneIA4EvIAGACIgEALAjmHDIEPBjIEHBgIioHNIrkkOIConNIDOBLIFrvoAGWnEIltPq");
	this.shape_104.setTransform(72.1,116);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#000000").s().p("AgFAXIgJgCIgCgCIgCgCIgEgKIgBgHQAAgBADgGIgCgBIAJgJQADgDACAAIAGgCQAEgCADAAIAGADQAMAIABAMIAAAEIgBAFIgCACIgIAKIgEACIgGACIgDABIgFgCg");
	this.shape_105.setTransform(105.9,44.9);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#FFFFFF").s().p("ApcNEIConMIDPBLIFqvoIjchPIIuneIA4EvIACANIgCgNIAHACIgFALIBMGZIjGhHIkShhIESBhIluPqIEHBgIinHMgAApImIkOhjgAFPrcIgGACQgDAAgCACIgJAKIACABQgDAGAAADIABAGIAEAKIABADIADACIAJACQAFACAFgBIAGgCIAEgCIAIgKIACgCIABgFIAAgGQgBgMgNgIIgFgDIgBAAIgIACg");
	this.shape_106.setTransform(72.1,116);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f().s("#000000").ss(1,1,1).p("AFUs+IAHACIgCAMICQGFIjPgjIkcgxIjpgnIHTo4IBsEgIAFAOABhJMIETAwIhVHjIsHiJIBVnjIDYAmIC5wYAEanOIi5QaAi7IZIEcAz");
	this.shape_107.setTransform(87.2,111.9);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#000000").s().p("AAAAZIgJgCIgDgBIgCgBIgGgKIgCgGQAAgDABgFIgCAAIAHgLQACgDADgBIAFgDQAGgDABAAIAHACQAMAGADAMIABAEIAAAEIgHAOIgEADIgGADIgFABIgCAAg");
	this.shape_108.setTransform(104.3,41.3);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#FFFFFF").s().p("AnoPWIBVnjIDYAmIC5wYIEcAxIkcgxIjpgnIHTo4IBsEgIAHACIgCAMICQGFIjPgjIi5QaIkcgzIEcAzIETAwIhVHjgACjrXIgFADQgDABgCADIgIALIADAAQgCAHABADIACAGIAGAKIABABIADABIAKACQAFABAEgCIAGgDIADgDIAIgOIAAgFIgBgFQgDgMgNgGIgGgCQgDAAgGADgAFZswIgFgOg");
	this.shape_109.setTransform(87.2,111.9);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f().s("#000000").ss(1,1,1).p("AB0s/IAHAAIAAAMIDSFmIjSABIkgACIjtACIFsqAICaEJIAHAMAB7JfIEYAAIAAHqIsUAAIAAnqIDcAAgAilJfIAAwpAB7nMIAAQr");
	this.shape_110.setTransform(109.4,109.8);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#000000").s().p("AgIAYIgCgBIgHgIIgEgGQAAgDAAgGIgDAAIAGgLQABgDADgBIAFgEQAEgEADgBIAFABQAOADAFALIACAGIABADIgBACIgFAMIgCAEIgGAEQgDACgGAAIgHABg");
	this.shape_111.setTransform(106.5,41.8);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#FFFFFF").s().p("AmBRJIAAnqIDcAAIEgAAIEYAAIAAHqgAilJfIAAwpIEggCIAAQrgAilJfgAgmxIICaEJIAHAMIDSFmIjSABIkgACIjtADgAgnq7IgEAEQgDABgBAEIgGAMIADAAQgBAGABADIADAGIAIAIIACACIADAAIAJAAQAGAAADgDIAFgEIADgDIAFgNIAAgCIAAgFIgCgFQgFgMgOgDIgHgBQgDABgFAEgAB7nMgAB7szIgHgMIAHAAIAAAMgAB0s/g");
	this.shape_112.setTransform(109.4,109.8);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f().s("#000000").ss(1,1,1).p("AhUtrIAHgCIACAMIELE8IjNAmIkdA1IjpArID3q2IDIDqIAJAKACrIbIEUgwIBVHiIsJCJIhVniIDZgmgAhxJOIi5wYAgNn/IC4Qa");
	this.shape_113.setTransform(114.9,113.4);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#000000").s().p("AgDAZIgDgBIgJgHIgEgFQgBgDgBgHIgCABIADgLIADgFIAEgFQAEgFADgBIAGAAQANABAHAKIADAFIABAFIAAACIgCALIgDAEIgEAFQgDADgFABIgHACg");
	this.shape_114.setTransform(94.6,43.4);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#FFFFFF").s().p("AlKJ0IDZgmIEcgzIkcAzIi4wYIEdg1IkdA1IjqArID3q2IDIDqIAJAKIEME8IjNAmIC3QaIEUgwIBUHiIsHCJgAjdquIAEAFIAJAGIACACIADAAIAKgDQAFgBADgCIAEgGIACgEIADgMIAAgCIgBgFIgDgFQgHgLgOgBIgHABQgDABgEAFIgEAFIgDAFIgDAMIACAAQABAHABADgAhLthgAhUtrIAHgCIACAMg");
	this.shape_115.setTransform(114.9,113.4);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f().s("#000000").ss(1,1,1).p("Akbt9IAGgDIAEAMAkbt9IAKAJIE/EIIjDBJIkQBlIjeBTIB7rWgADWHHIEHhfICnHMIrkEOIionNIDQhKgAg4IrIltvpAiVojIFrPq");
	this.shape_116.setTransform(119.7,118);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#000000").s().p("AgCAYIgJgFIgFgEQgCgCgCgHIgCABIABgLQAAgEACgCIADgGQADgFADgBIAGgCQANgBAJAIIADAFIACAHIAAALIgBAEIgEAGQgCADgFACIgJAEIgCAAg");
	this.shape_117.setTransform(82.8,48);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("#FFFFFF").s().p("AkIJ1IDQhKIEOhkIkOBkIltvpIjeBTIB7rWIDtDEIAKAJIE/EIIjDBJIkQBlIEQhlIFrPqIEHhfICnHMIrkEOgAmBqsIAFAFIAJAFIADABIADgBIAJgEQAFgCACgDIAEgGIABgEIAAgNIgCgHIgDgEQgJgJgPACIgGABQgDACgDAFIgDAGQgCACAAADIgBANIACgBQACAHACACgAkbt9IAGgDIAEAMg");
	this.shape_118.setTransform(119.7,118);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f().s("#000000").ss(1,1,1).p("AD9FlIDyiMID1GoIqrGMIj0mpIC9hugAnLttIFpDMIi1BrIj7CTIjMB4IgFrhIELCYIAHgEgAnYt0IANAHAACH2IoUuZAkXo2IIUOb");
	this.shape_119.setTransform(123.4,123.4);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f("#000000").s().p("AAAAZIgJgEQgBgCgEgBQgDgCgCgHIgCACIgBgLQgBgEACgCIACgGQACgGACgCIAGgDQAMgEAKAHIAFAEIADAHIACAKIgBAFIgCAGQgCAEgEACIgIAGIgDABg");
	this.shape_120.setTransform(71.2,55.5);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f("#FFFFFF").s().p("Ai7JkIC9huID7iRIDziMID0GoIqrGMgAoRmjID5iTIIVObIj7CRgAD9FlgArjwMIELCYIAHgEIAFALIgMgHIAMAHIFqDMIi2BrIj5CTIjNB4gAoXqUQADACACACIALADIADABIACgBIAIgGQAFgDACgDIACgHIABgEIgDgNIgCgGIgFgEQgKgHgOAEIgGADQgDABgCAGIgCAHQgBACAAADIABANIACgBQADAGADACg");
	this.shape_121.setTransform(123.4,123.4);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f().s("#000000").ss(1,1,1).p("Akbt+IAGgCIAEAMAkbt+IAKAKIE/EIIjEBKIkPBkIjeBTIB7rWgADWHHIEHhfICnHMIrjEOIionNIDPhLgAg4IqIltvoAiWoiIFsPp");
	this.shape_122.setTransform(120.6,117.5);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f("#000000").s().p("AgMATIgEgEQgDgDgBgHIgCABIABgLQAAgDACgCIADgGQADgFACgBIAHgCQAMgCAKAJIADAFIACAGIAAALIgFAKQgCAEgFABIgJAFIgCAAg");
	this.shape_123.setTransform(83.8,47.5);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f("#FFFFFF").s().p("AkHJ1IDPhLIEOhjIkOBjIltvoIjeBTIB7rWIDtDDIAKAKIE/EIIjEBKIkPBkIEPhkIFsPpIEHhfICnHMIrjEOgAmBqrIAFAEIAMAGIADAAIAJgFQAFgBACgEIAGgKIgBgNIgCgGIgDgFQgJgJgOACIgHACQgDABgDAFIgDAGQgCACAAADIgBANIACgBQACAHACADgAkbt+IAGgCIAEAMg");
	this.shape_124.setTransform(120.6,117.5);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f().s("#000000").ss(1,1,1).p("AhUtsIAHgBIACAMIEME8IjOAmIkdA0IjpArID4q2IDHDqIAJALACrIbIEUgwIBVHiIsICKIhVnkIDZglgAhwJOIi6wZAgNn/IC4Qa");
	this.shape_125.setTransform(116.7,112.2);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f("#000000").s().p("AgDAZIgLgJIgFgEQgBgDgBgHIgCABIADgLQABgDADgCIADgFQAEgFADAAIAGgCQANACAHAKIADAFIABAHIgCAKIgHAJQgDAEgEABIgJACg");
	this.shape_126.setTransform(96.5,42.2);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f("#FFFFFF").s().p("AlJJ0IDZgmIEbgzIkbAzIi6wYIEdg1IkdA1IjpArID4q2IDHDpIAJAMIEME7IjOAmIC4QaIEUgwIBVHiIsICKgAjdquIAEAEIAMAJIACAAIAKgCQAFgBADgEIAHgJIACgMIgBgHIgDgFQgHgKgOgCIgHACQgDAAgEAFIgEAFQgCACgBADIgDANIACgBQABAHABADgAhLtggAhUtsIAHgBIACANg");
	this.shape_127.setTransform(116.7,112.2);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f().s("#000000").ss(1,1,1).p("AB0s/IAHAAIgBAMAB0s/IAGAMIDUFmIjUABIkfACIjtACIFsqAgAB7JfIEYAAIgBHqIsTAAIAAnrIDcABgAilJfIAAwpAB6nMIABQr");
	this.shape_128.setTransform(111.8,107.6);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f("#000000").s().p("AgIAYIgJgKIgEgFQgBgEABgFIgDAAIAGgLQABgDADgBIAFgFQAEgEADAAIAGABQAMADAHALIACAFIgBAGIgEAMIgJAHQgDADgFAAIgIABg");
	this.shape_129.setTransform(108.9,39.7);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.f("#FFFFFF").s().p("AmBJeIDcABIAAwpIjtACIFsqAICaEJIAGANIgGgNIAHAAIgBANIDUFlIjUACIkfABIEfgBIABQqIkgAAIEgAAIEYABIgBHpIsTAAgAgyqcIADAFIAKAKIADABIAKgBQAEAAAEgDIAJgHIADgMIABgIIgCgFQgGgLgMgDIgIgBQgDAAgFAEIgEAFQgDABgBADIgGALIADAAQgBAHABAEg");
	this.shape_130.setTransform(111.8,107.6);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.f().s("#000000").ss(1,1,1).p("ADytBIAHABIgCAMADytBIAFANIC0F2IjTgRIkfgXIjsgSIGgpfgAijI/IEeAZIEXAZIgsHnIsQhEIArnpIDcAUIBcwlADYnPIhdQn");
	this.shape_131.setTransform(106.4,109.1);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.f("#000000").s().p("AgIAZIgCgBIgJgLQgBgDgCgDQgBgDACgGIgDAAIAHgLQABgCADgBIAFgEQAFgEADAAIAGABQAMAFAFALIACAGIgCAFIgFAMIgJAHQgEACgEgBIgEABIgFAAg");
	this.shape_132.setTransform(114.8,39.6);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.f("#FFFFFF").s().p("AmqQUIArnpIDcAUIEeAZIkegZIBcwlIjsgSIGgpfICFEWIAFANIgFgNIAHABIgCAMIC0F2IjTgRIkfgXIEfAXIhdQnIEXAZIgsHngABKrLIgFAEQgDABgBADIgHALIADAAQgCAHABAEQACADABACIAJALIACABQAHABAEgBQAEAAAEgCIAJgHIAFgMIACgHIgCgFQgFgMgMgEIgIgCQgDAAgFAEg");
	this.shape_133.setTransform(106.4,109.1);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.f().s("#000000").ss(1,1,1).p("AFTs9IAIABIgEAMAFTs9IAEANICTGFIjRgkIkbgwIjqgmIHUo4gAi7IaIEbAyIEUAxIhWHhIsHiIIBVnjIDZAnIC5wZAEZnPIi5Qb");
	this.shape_134.setTransform(103.8,111.1);

	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.f("#000000").s().p("AgKAZIgCgCIgIgLIgDgGQAAgEACgFIgDAAIAIgLQACgCADgBIAFgDQAFgEABAAIAIACQAMAGAEAMIABAEIgCAGIgGAMIgKAGQgEACgDgBIgEAAIgGAAg");
	this.shape_135.setTransform(120.8,40.6);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.f("#FFFFFF").s().p("AnpPWIBVnjIDZAnIEbAyIkbgyIC5wZIjqgmIHUo4IBrEgIAEANIgEgNIAIABIgEAMICTGFIjRgkIkbgwIEbAwIi5QbIEUAxIhWHhgACirWIgFAEQgDAAgCADIgIAKIADAAQgCAIAAADIADAGIAIAMIACABQAHABAEgBQAEABAEgBIAKgHIAGgLIACgHIgBgGQgEgMgMgFIgIgCIgBAAQgCAAgFADg");
	this.shape_136.setTransform(103.8,111.1);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.f().s("#000000").ss(1,1,1).p("AFUs9IAHACIgEAMAFUs9IADAOICTGEIjRgkIkbgwIjqgmIHUo4gAi7IaIEbAyIEUAxIhWHhIsHiIIBVnjIDZAnIC5wZAEZnPIi5Qb");
	this.shape_137.setTransform(103.6,110.9);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.f("#000000").s().p("AgKAZIgCgCIgIgLQAAgDgDgEIACgIIgCgBIAHgKQABgDADAAIAGgEQAFgEABABIAHACQAMAFAEAMIABAFIgCAGIgGAMIgKAGQgDABgDgBIgFABIgFAAg");
	this.shape_138.setTransform(120.7,40.4);

	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.f("#FFFFFF").s().p("AnpPWIBVnjIDZAnIEbAyIkbgyIC5wZIjqgmIHUo4IBsEgIADAOIgDgOIAHACIgEAMICTGEIjRgkIkbgwIEbAwIi5QbIEUAxIhWHhgACirWIgGAEQgDAAgBADIgHAKIACABIgCAKQADAEAAADIAIALIACACQAHABAEgCQAEABAEgBIAKgGIAGgMIACgHIgBgGQgEgMgMgFIgIgCIgBAAQgCAAgFADg");
	this.shape_139.setTransform(103.6,110.9);

	this.shape_140 = new cjs.Shape();
	this.shape_140.graphics.f().s("#000000").ss(1,1,1).p("ADztBIAGABIgCAMADztBIAEANIC0F2IjTgSIkegXIjtgRIGhpfgAijI/IEfAYIEWAaIgrHnIsRhFIAsnpIDbAVIBdwmADYnQIhcQn");
	this.shape_140.setTransform(105.6,108);

	this.shape_141 = new cjs.Shape();
	this.shape_141.graphics.f("#000000").s().p("AgIAZIgCgBIgJgLQAAgDgEgDIACgIIgDgBIAGgLQACgDADAAIAFgEQAEgFADAAIAGABQANAFAFAMIACAGIgCAFIgFAMIgJAHQgEACgEgBQgCACgEAAIgDgBg");
	this.shape_141.setTransform(114,38.6);

	this.shape_142 = new cjs.Shape();
	this.shape_142.graphics.f("#FFFFFF").s().p("AmqQTIAsnpIDbAVIEeAYIkegYIBdwmIjtgRIGhpfICEEWIAFANIgFgNIAHABIgCAMIC0F2IjTgSIkegXIEeAXIhdQnIEXAaIgsHngABLrLIgGAEQgDABgBADIgGALIACAAIgCALQAEADAAADIAJAKIADACQAFAAAFgCQAFABADgBIAKgIIAEgMIACgHIgCgGQgFgMgNgEIgIgBIAAAAQgDAAgDAEg");
	this.shape_142.setTransform(105.6,108);

	this.shape_143 = new cjs.Shape();
	this.shape_143.graphics.f().s("#000000").ss(1,1,1).p("AB1s/IAHAAIgCANAB1s/IAFANIDVFkIjVABIkeACIjuAFIFsqCgAB8JeIEXACIgBHoIsUABIACnrIDcABgAikJfIAAwqAB6nNIACQr");
	this.shape_143.setTransform(110.8,106);

	this.shape_144 = new cjs.Shape();
	this.shape_144.graphics.f("#000000").s().p("AgIAYIgJgJQgBgDgEgDIABgJIgDAAIAFgLQABgEADAAIAFgFQAEgFADAAIAGAAQAOAEAGALIACAGIgBAFIgEANIgJAIQgDACgFgBQgDADgFAAg");
	this.shape_144.setTransform(107.9,38.2);

	this.shape_145 = new cjs.Shape();
	this.shape_145.graphics.f("#FFFFFF").s().p("AmAJeIDcABIgBwqIjtAFIFsqCICbEJIAFANIgFgNIAGAAIgBANIDVFkIjVABIkfACIEfgCIABQrIkfABIEfgBIEYACIgBHoIsTABgAgnq6IgEAEQgEABgBADIgEAMIACAAIAAAKQADADABADIAJAKIADABQAGAAAEgCQAFAAADgBIAJgJIAEgMIABgHIgCgGQgGgMgNgDIgJAAIAAAAQgDAAgEAFg");
	this.shape_145.setTransform(110.8,106);

	this.instance_15 = new lib.Symbol3();
	this.instance_15.setTransform(109.4,109.8,1,1,0,0,0,40.3,109.8);
	this.instance_15._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_14}]}).to({state:[{t:this.instance_14}]},1).to({state:[{t:this.instance_14}]},1).to({state:[{t:this.instance_14}]},1).to({state:[{t:this.instance_14}]},1).to({state:[{t:this.instance_14}]},1).to({state:[{t:this.instance_14}]},1).to({state:[{t:this.instance_14}]},1).to({state:[{t:this.instance_14}]},1).to({state:[{t:this.shape_94},{t:this.shape_93},{t:this.shape_92}]},1).to({state:[{t:this.shape_97},{t:this.shape_96},{t:this.shape_95}]},1).to({state:[{t:this.shape_100},{t:this.shape_99},{t:this.shape_98}]},1).to({state:[{t:this.shape_103},{t:this.shape_102},{t:this.shape_101}]},1).to({state:[{t:this.shape_106},{t:this.shape_105},{t:this.shape_104}]},1).to({state:[{t:this.shape_109},{t:this.shape_108},{t:this.shape_107}]},1).to({state:[{t:this.shape_112},{t:this.shape_111},{t:this.shape_110}]},1).to({state:[{t:this.shape_115},{t:this.shape_114},{t:this.shape_113}]},1).to({state:[{t:this.shape_118},{t:this.shape_117},{t:this.shape_116}]},1).to({state:[{t:this.shape_121},{t:this.shape_120},{t:this.shape_119}]},1).to({state:[{t:this.shape_124},{t:this.shape_123},{t:this.shape_122}]},1).to({state:[{t:this.shape_127},{t:this.shape_126},{t:this.shape_125}]},1).to({state:[{t:this.shape_130},{t:this.shape_129},{t:this.shape_128}]},1).to({state:[{t:this.shape_133},{t:this.shape_132},{t:this.shape_131}]},1).to({state:[{t:this.shape_136},{t:this.shape_135},{t:this.shape_134}]},1).to({state:[{t:this.shape_139},{t:this.shape_138},{t:this.shape_137}]},1).to({state:[{t:this.shape_142},{t:this.shape_141},{t:this.shape_140}]},1).to({state:[{t:this.shape_145},{t:this.shape_144},{t:this.shape_143}]},1).to({state:[{t:this.instance_15}]},2).to({state:[{t:this.instance_15}]},1).to({state:[{t:this.instance_15}]},1).to({state:[{t:this.instance_15}]},1).to({state:[{t:this.instance_15}]},1).to({state:[{t:this.instance_15}]},1).to({state:[{t:this.instance_15}]},1).to({state:[{t:this.instance_15}]},1).to({state:[]},1).wait(125));
	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(1).to({regY:109.7,rotation:-10,x:97.4,y:-25.8},0).wait(1).to({regX:40.4,rotation:-20,x:84.4,y:-22.3},0).wait(1).to({regX:40.3,rotation:-30,x:73.2,y:-16.9},0).wait(1).to({rotation:-50,x:56.2,y:-0.5},0).wait(1).to({rotation:-60,x:48.1,y:9},0).wait(1).to({rotation:-70,x:46,y:21.4},0).wait(1).to({regX:40.2,rotation:-100,x:46.1,y:58.9},0).wait(1).to({regX:40.3,rotation:-110,x:50.8,y:68.2},0).to({_off:true},1).wait(152));
	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(28).to({_off:false},0).wait(1).to({x:83.2,y:91.4},0).wait(1).to({x:57.1,y:73},0).wait(1).to({x:31,y:54.6},0).wait(1).to({x:4.8,y:36.1},0).wait(1).to({x:-21.3,y:17.7},0).wait(1).to({x:-47.5,y:-0.7},0).wait(1).to({x:-73.6,y:-19.2},0).to({_off:true},1).wait(125));

	// Ground
	this.shape_146 = new cjs.Shape();
	this.shape_146.graphics.f().s("#000000").ss(1,1,1).p("AovxGIRfAAMAAAAiNIxfAAg");
	this.shape_146.setTransform(125.1,344.5);

	this.shape_147 = new cjs.Shape();
	this.shape_147.graphics.f("#FFFFFF").s().p("AovRGMAAAgiMIRfAAMAAAAiMg");
	this.shape_147.setTransform(125.1,344.5);

	this.instance_16 = new lib.Symbol5();
	this.instance_16.setTransform(125.1,344.5,1,1,0,0,0,56,109.5);
	this.instance_16._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_147},{t:this.shape_146}]}).to({state:[{t:this.instance_16}]},28).to({state:[{t:this.instance_16}]},1).to({state:[{t:this.instance_16}]},1).to({state:[{t:this.instance_16}]},1).to({state:[{t:this.instance_16}]},1).to({state:[{t:this.instance_16}]},1).to({state:[{t:this.instance_16}]},1).to({state:[{t:this.instance_16}]},1).to({state:[]},1).wait(125));
	this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(28).to({_off:false},0).wait(1).to({x:98.9,y:326.1},0).wait(1).to({x:72.8,y:307.6},0).wait(1).to({x:46.7,y:289.2},0).wait(1).to({x:20.5,y:270.8},0).wait(1).to({x:-5.6,y:252.4},0).wait(1).to({x:-31.8,y:233.9},0).wait(1).to({x:-57.9,y:215.5},0).to({_off:true},1).wait(125));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(343.1,64.5,666.5,593);

})(lib = lib||{}, images = images||{}, createjs = createjs||{}, ss = ss||{});
var lib, images, createjs, ss;